$(function () {

    $('#search-input').on('change paste keyup', function () {
        var keywords = $('#search-input').val();
        var timer;
        timer = setTimeout(function () {

            $.get('/search/executeSearch/blog', {keywords: keywords}, function (data) {
                if (keywords == '') {
                    $('.blog-keywords').text('All Blogs');
                } else {
                    $('.blog-keywords').html('Blogs that contain \"<em>' + keywords + '</em>\"');

                }

                $('#results').html(data.posts);
                $('.blog-nav').html(data.pagination);
                // $('#search-input').val(keywords);

            });
        }, 300);

    });

    $('#testimonies-search-input').on('change paste keyup', function () {
        var keywords = $('#testimonies-search-input').val();
        var timer;
        timer = setTimeout(function () {

            $.get('/search/executeSearch/testimonies', {keywords: keywords}, function (data) {
                if (keywords == '') {
                    $('.testimonies-keywords').text('All Testimonies');
                } else {
                    $('.testimonies-keywords').html('Testimonies that contain \"<em>' + keywords + '</em>\"');

                }

                $('#results').html(data.posts);
                $('.testimony-nav').html(data.pagination);
                // $('#search-input').val(keywords);

            });
        }, 300);

    });

    $('#contact-search-input').on('change paste keyup', function () {
        var keywords = $('#contact-search-input').val();
        var timer;
        timer = setTimeout(function () {

            $.get('/search/executeSearch/contact', {keywords: keywords}, function (data) {
                if (keywords == '') {
                    $('.contact-keywords').text('All Contact Forms');
                } else {
                    $('.contact-keywords').html('Contact Forms that contain \"<em>' + keywords + '</em>\"');

                }

                $('#results').html(data.posts);
                $('.contact-nav').html(data.pagination);
                // $('#search-input').val(keywords);

            });
        }, 300);

    });


    $('#prayer-search-input').on('change paste keyup', function () {
        var keywords = $('#prayer-search-input').val();
        var timer;
        timer = setTimeout(function () {

            $.get('/search/executeSearch/prayer', {keywords: keywords}, function (data) {
                if (keywords == '') {
                    $('.prayer-keywords').text('All Prayer Request');
                } else {
                    $('.prayer-keywords').html('Prayer Request that contain \"<em>' + keywords + '</em>\"');

                }

                $('#results').html(data.posts);
                $('.prayer-nav').html(data.pagination);
                // $('#search-input').val(keywords);

            });
        }, 300);

    });

    $('#tracts-search-input').on('change paste keyup', function () {
        var keywords = $('#tracts-search-input').val();
        var timer;
        timer = setTimeout(function () {

            $.get('/search/executeSearch/tracts', {keywords: keywords}, function (data) {
                if (keywords == '') {
                    $('.tracts-keywords').text('All Tracts');
                } else {
                    $('.tracts-keywords').html('Tracts like \"<em>' + keywords + '</em>\"');

                }

                $('#results').html(data.posts);
                $('.tracts-nav').html(data.pagination);
                // $('#search-input').val(keywords);

            });
        }, 300);

    });

    $('#workers-search-input').on('change paste keyup', function () {
        var keywords = $('#workers-search-input').val();
        var timer;
        timer = setTimeout(function () {

            $.get('/search/executeSearch/workers', {keywords: keywords}, function (data) {
                if (keywords == '') {
                    $('.workers-keywords').text('All Workers');
                } else {
                    $('.workers-keywords').html('Workers name like  \"<em>' + keywords + '</em>\"');

                }

                $('#results').html(data.posts);
                $('.workers-nav').html(data.pagination);
                // $('#search-input').val(keywords);

            });
        }, 300);

    });


    $('#users-search-input').on('change paste keyup', function () {
        var keywords = $('#users-search-input').val();
        var timer;
        timer = setTimeout(function () {

            $.get('/search/executeSearch/users', {keywords: keywords}, function (data) {
                if (keywords == '') {
                    $('.users-keywords').text('All Users');
                } else {
                    $('.users-keywords').html('Users name like  \"<em>' + keywords + '</em>\"');

                }

                $('#results').html(data.posts);
                $('.users-nav').html(data.pagination);
                // $('#search-input').val(keywords);

            });
        }, 300);

    });


    $('h1.you-chose').hide();
    // $('h1.you-chose strong')
    $('#your_input').datepicker({
        onSelect: function(date) {
            $('h1.you-chose strong').text($('#your_input').val());
            $('h1.you-chose').show();
            if ($('.chosen_date').length >= 1){
                $('.chosen_date').val($('#your_input').val());
            } else {
                $('<input>').attr({
                    type: 'hidden',
                    name: 'chosen_date',
                    class: 'chosen_date',
                    value: $('#your_input').val(),
                }).appendTo('form');
            }
            $('#main_form').show();
        },
        minDate: 0
    });

    $('#other').hide();
    $('#how_did_you_hear').on('change', function() {
        if(this.value == 'Other' ){
            $('#other').show();
            $('#other').attr('required','required');
        } else {
            $('#other').hide();
        }
    });

    $('#contactForm').bind('submit', function(e) {
        $('#submitBtn').attr('disabled', 'disabled');
        $("#submitBtn").html('<img src="/img/small_grey_loader.gif"/> Processing...');

    });

});