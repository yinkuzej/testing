<?php
/* 	NOTES
 *  Jika hanya menampilkan data pribadi saja , cukup masukan userId dan accesToken
 *  Jika diperlukan autentikasi login semua nya wajib di isi 
 */

return [
    'userId' => '297934594',
    'accessToken' => '297934594.1677ed0.96067423aedd4652920c26c59b70a3b7',
    'clientId' => 'a7b2a7da38674f2883278d045c13471b',
    'clientSecret' => '95c4cceb161e457b82dc70cbf13cfc5e',
    'redirectUri' => 'http://www.jordan.test.org/interactive/prayer-request',
];
