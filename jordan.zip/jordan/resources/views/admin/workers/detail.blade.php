@extends('layouts.backend')

@section('content')
    <br><br><br><br><br><br><br><br>
    <!-- Blog Heading -->
    <div class="row">
        <div class="col-lg-12">
            <h2 class="Blog-header">
                {{ $worker->title }}
            </h2>
            <div class="pull-right">
                <a href="{{ asset('/admin/workers/' . $worker->id . '/edit') }}" class="btn btn-info">EDIT</a>
            </div>
            <div class="pull-right">
                <form action="{{ asset('/admin/workers/' . $worker->id) }}" method="POST">
                    {{ method_field('DELETE') }}
                    {{ csrf_field() }}
                    <input type="submit" class="btn btn-danger" value="DELETE">
                </form>
            </div>
            <ol class="breadcrumb">
                <li>
                    <i class="fa fa-dashboard"></i>  <a href="{{ asset('/admin/blogs') }}">Worker</a>
                </li>
                <li class="active">
                    <i class="fa fa-edit"></i> Detail
                </li>
            </ol>
        </div>
    </div>
    <!-- /.row -->

    <div class="row">

        <div class="col-lg-6">

            <div class="form-group">
                <label>First Name</label>
                <p>{{ $worker->first_name }}</p>
            </div>

            <div class="form-group">
                <label>Last Name</label>
                <p>{{ $worker->last_name }}</p>
            </div>

            <div class="form-group">
                <label>Email</label>
                <p>{{ $worker->email }}</p>
            </div>

        </div>

        <a class="btn btn-default" href="{{ asset('/admin/workers/') }}">Back</a>
        <a class="btn btn-warning" href="{{ asset('/admin/workers/'.$worker->id.'/edit') }}">Edit</a>
        <form action="/admin/workers//{{$worker->id}}/delete" method="DELETE" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><button class="btn btn-danger" type="submit">Delete</button></form>

    </div>
    <!-- /.row -->

@endsection
