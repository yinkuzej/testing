@extends('layouts.backend')

@section('content')
    <br><br><br><br><br><br><br><br>

    <div class="ui fluid input icon">
        <div class="ui icon input">
            <input class="prompt" id="workers-search-input" type="text" value="{{(!empty($keywords)? $keywords :'')}}" placeholder="Search Worker By First or Last Name ">
            <i class="search icon"></i>
        </div>
    </div>
    <div class="row">
        <div class="page-header">
            @if(!empty($keywords))
                <h2 class="workers-keywords">Workers with name like "<em>{{$keywords}}</em>"</h2>
            @else
                <h2 class="workers-keywords">All Workers</h2>
            @endif
        </div>


        <div class="row">
    <div class="col-md-12">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                {{--<th>END</th>--}}
                {{--<th>ALL DAY EVENT</th>--}}
                {{--<th>BACKGROUND_COLOR</th>--}}
                <th class="text-right">OPTIONS</th>
            </tr>
            </thead>

            <tbody id="results">

            @foreach($workers as $worker)
                <tr>
                    <td>{{ucfirst(strtolower($worker->first_name)) .' '. ucfirst(strtolower($worker->last_name)) }}</td>
                    <td>{{$worker->email}}</td>
                    {{--<td>{{$worker->po}}</td>--}}
                    {{--<td>{{$worker->end}}</td>--}}
                    {{--<td>{{$worker->allDay}}</td>--}}
                    {{--<td>{{$worker->background_color}}</td>--}}

                    <td class="text-right">
                        <a class="btn btn-primary" href="{{ route('workers.show', $worker->id) }}">View</a>
                        <a class="btn btn-warning " href="{{ route('workers.edit', $worker->id) }}">Edit</a>
                        <a class="btn btn-warning " href="/admin/workers/{{$worker->id}}/permissions">Change Permissions</a>
                        <form action="{{ route('workers.destroy', $worker->id) }}" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><input type="hidden" name="_method" value="DELETE"><input type="hidden" name="_token" value="{{ csrf_token() }}"> <button class="btn btn-danger" type="submit">Delete</button></form>
                    </td>
                </tr>

            @endforeach

            </tbody>
        </table>
        {{--<a class="btn btn-success" href="{{ route('calendar_events.create') }}">Create</a>--}}
        <div class="workers-nav">
            {{ $workers->links() }}

        </div>
    </div>
    </div>
@stop