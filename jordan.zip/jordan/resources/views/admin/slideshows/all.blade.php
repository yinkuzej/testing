@extends('layouts.backend')

@section('content')
    <br><br><br><br><br><br><br><br>

    <div class="row">
        <div class="col-lg-12">
                <h2 class="testimonies-keywords">All Slideshows</h2>
        </div>



        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Title</th>
                        <th>Image</th>
                        <th class="text-right">OPTIONS</th>
                    </tr>
                    </thead>

                    <tbody id="results">

                    @foreach($slideshows as $slideshow)
                        <tr>
                            <td>{{$slideshow->title}}</td>
                            <td>{{$slideshow->image}}</td>

                            <td class="text-right">
                                <input type="checkbox" {{($slideshow->display =='yes'?'checked':'' )}} data-toggle="toggle" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="danger">
                                <a class="btn btn-warning " href="{{ asset('/admin/slideshow/'.$slideshow->id.'/edit') }}">Edit</a>
                                <form action="/admin/slideshow/{{$slideshow->id}}/delete" method="DELETE" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><button class="btn btn-danger" type="submit">Delete</button></form>
                            </td>
                        </tr>

                    @endforeach

                    </tbody>
                </table>

                <a class="btn btn-success" href="{{ asset('/admin/testimony/create') }}">Create</a>
            </div>
        </div>
        <div class="testimony-nav">

            {{ $slideshows->links() }}

        </div>
@stop