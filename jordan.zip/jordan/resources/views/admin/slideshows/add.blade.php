@extends('layouts.backend')

@section('content')

    <div class="container">
        <div class="row">


            <form role="form" enctype="multipart/form-data" action="{{ asset('/admin/slideshow/submit') }}" method="post">

                {{ csrf_field() }}


                <div class="form-group">
                    <label for="name">Your Name</label>
                    <input type="text" class="form-control" name="title" id="name" placeholder="Enter Name" required>
                </div>
                <div class="form-group">
                    <label for="subject">Title</label>
                    <input type="subject" class="form-control" id="link" name="link" placeholder="Enter Title"
                           required>
                </div>

                <div class="form-group">
                    <label for="image">Image</label>
                    <input name="file" id="file" class="form-control"  type="file" required>
                </div>
                <div class="form-group">
                    <label for="display">Display</label>
                    <input name="display" type="checkbox" checked data-toggle="toggle" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="danger">
                </div>

                <div class="ui large buttons">
                    <button type="submit" class="ui button">Submit</button>
                    <div class="or"></div>
                    <button type="reset" class="ui button">Reset</button>
                </div>
            </form>
        </div>

    </div>

@stop