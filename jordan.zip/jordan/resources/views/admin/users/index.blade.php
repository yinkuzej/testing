@extends('layouts.backend')

@section('content')
    <br><br><br><br><br><br><br><br>

    <div class="ui fluid input icon">
        <div class="ui icon input">
            <input class="prompt" id="users-search-input" type="text" value="{{(!empty($keywords)? $keywords :'')}}" placeholder="Search User By First or Last Name ">
            <i class="search icon"></i>
        </div>
    </div>
    <div class="row">
        <div class="page-header">
            @if(!empty($keywords))
                <h2 class="users-keywords">Users with name like "<em>{{$keywords}}</em>"</h2>
            @else
                <h2 class="users-keywords">All Users</h2>
            @endif
        </div>


        <div class="row">
    <div class="col-md-12">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                {{--<th>END</th>--}}
                {{--<th>ALL DAY EVENT</th>--}}
                {{--<th>BACKGROUND_COLOR</th>--}}
                <th class="text-right">OPTIONS</th>
            </tr>
            </thead>

            <tbody id="results">

            @foreach($workers as $user)
                <tr>
                    <td>{{ucfirst(strtolower($user->first_name)) .' '. ucfirst(strtolower($user->last_name)) }}</td>
                    <td>{{$user->email}}</td>
                    {{--<td>{{$user->po}}</td>--}}
                    {{--<td>{{$user->end}}</td>--}}
                    {{--<td>{{$user->allDay}}</td>--}}
                    {{--<td>{{$user->background_color}}</td>--}}

                    <td class="text-right">
                        <a class="btn btn-primary" href="{{ route('users.show', $user->id) }}">View</a>
                        <a class="btn btn-warning " href="{{ route('users.edit', $user->id) }}">Edit</a>
                        <a class="btn btn-warning " href="/admin/users/{{$user->id}}/permissions">Change Permissions</a>
                        <form action="{{ route('users.destroy', $user->id) }}" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><input type="hidden" name="_method" value="DELETE"><input type="hidden" name="_token" value="{{ csrf_token() }}"> <button class="btn btn-danger" type="submit">Delete</button></form>
                    </td>
                </tr>

            @endforeach

            </tbody>
        </table>
        {{--<a class="btn btn-success" href="{{ route('calendar_events.create') }}">Create</a>--}}
        <div class="users-nav">
            {{ $workers->links() }}

        </div>
    </div>
    </div>
@stop