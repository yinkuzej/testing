@extends('layouts.backend')

@section('content')

    <br><br><br><br><br><br><br><br>
    <form class="ui fluid form" role="form" action="/admin/users/{{$user->id}}" method="POST">

        {{ csrf_field() }}
        {{ method_field('PUT') }}

        <input type="hidden"  name="id"  value="{{$user->id}}" required>

        <div class="field ui focus">
            <label>First Name</label>
            <input type="text" name="first_name" id="first_name" placeholder="First name" value="{{$user->first_name}}">
        </div>
        <div class="ui divider"></div>
        <div class="field ui focus">
            <label>Last Name</label>
            <input type="text" name="last_name" id="last_name" placeholder="Last Name"  value="{{$user->last_name}}">
        </div>
        <div class="ui divider"></div>
        <div class="field ui focus">
            <label>Phone Number</label>
            <input type="tel" name="phone" id="phone" placeholder="Phone number" value="{{$user->phone}}">
        </div>
        <div class="ui divider"></div>
        <div class="field ui focus">
            <label>Email Address</label>
            <input type="email" name="email" id="email" placeholder="Email Address" value="{{$user->email}}">
        </div>
        <div class="ui divider"></div>

        <div class="ui large buttons">
            <button type="submit" class="ui button">Submit</button>
            <div class="or"></div>
            <button type="reset" class="ui button">Reset</button>
        </div>
    </form>

@stop