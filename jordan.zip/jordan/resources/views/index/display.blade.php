@extends('../layouts.app')

@section('content')
    <div class="container">

    </div>
@stop
@section('footer')
    <p>&copy; 2016 www.rccg.com, Inc.</p>
@stop