@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12 bg-info">
                <form class="form-horizontal">
                    <fieldset>

                        <!-- Form Name -->
                        <legend>My Info</legend>

                        <!-- Text input-->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="username">Username</label>
                            <div class="col-md-8">
                                <input id="username" name="username" type="text" placeholder="Username"
                                       class="form-control input-md" value=" {{  $user->username }} ">

                            </div>
                        </div>

                        <!-- Text input-->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="first_name">First Name</label>
                            <div class="col-md-8">
                                <input id="first_name" name="first_name" type="text" placeholder="First Name"
                                       class="form-control input-md" value=" {{  $user->first_name }} ">

                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-3 control-label" for="last_name">Last Name</label>
                            <div class="col-md-8">
                                <input id="last_name" name="last_name" type="text" placeholder="Last Name"
                                       class="form-control input-md" value=" {{  $user->last_name }} ">

                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-3 control-label" for="address">Address</label>
                            <div class="col-md-8">
                                <input id="address" name="address" type="text" placeholder="Address"
                                       class="form-control input-md" value=" {{  $user->address }} ">

                            </div>
                        </div>

                        <!-- Text input-->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="date_of_birth">Date Birthday</label>
                            <div class="col-md-8">
                                <input id="date_of_birth" name="date_of_birth" type="date" placeholder="Date Birthday"
                                       class="form-control input-md" value=" {{  $user->date_of_birth }} ">

                            </div>
                        </div>

                        <!-- Select Basic -->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="gender">Gender</label>
                            <div class="col-md-8">
                                {!! Form::select('gender', ['M' => 'Male', 'F' => 'Female'], $user->gender, ['class' => 'form-control', 'id' => 'gender']) !!}
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-3 control-label" for="married">Marital Status</label>
                            <div class="col-md-8">
                                {!! Form::select('married', ['Single' => 'single', 'married' => 'Married'], $user->married, ['class' => 'form-control', 'id' => 'married']) !!}

                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-3 control-label" for="date_of_anniversary">Date Birthday</label>
                            <div class="col-md-8">
                                <input id="date_of_anniversary" name="date_of_anniversary" type="date"
                                       placeholder="host" class="form-control input-md" value=" {{  $user->date_of_anniversary }} ">
                            </div>
                        </div>

                        <!-- File Button -->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="filebutton">upload photo</label>
                            <div class="col-md-8">
                                <input id="filebutton" name="filebutton" class="input-file" type="file">
                            </div>
                        </div>

                        <!-- Button -->
                        <div class="form-group">
                            <label class="col-md-3 control-label" for="singlebutton"></label>
                            <div class="col-md-8">
                                <button id="singlebutton" name="singlebutton" class="btn btn-primary">Update</button>
                            </div>
                        </div>

                    </fieldset>
                </form>
            </div>

            <div class="col-md-5 col-sm-5 col-xs-12 bg-info col-md-offset-1 col-sm-offset-1">

                <form class="form-horizontal" role="form" method="POST" action="{{ url('/password/update') }}">
                    {{ csrf_field() }}

                    <legend>Reset Password</legend>

                    <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                        <label for="password" class="col-md-4 control-label">New Password</label>

                        <div class="col-md-7">
                            <input id="password" type="password" class="form-control" name="password" required>

                            @if ($errors->has('password'))
                                <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                            @endif
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                        <div class="col-md-7">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-4">
                            <button type="submit" name="reset" class="btn btn-primary">
                                Reset
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@stop
@section('footer')
    <p>&copy; 2016 www.rccg.com, Inc.</p>
@stop