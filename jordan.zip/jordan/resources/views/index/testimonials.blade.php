<section id="our-client" class="sections different-bg">
    <div class="container text-center">

        <!-- Example row of columns -->
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12">


                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel" data-interval="3000">


                    <!-- Wrapper for slides -->
                    <div class="carousel-inner" role="listbox">

                        <div class="item active">
                            <div class="client-content">
                                <h3>What Our Clients are saying</h3>
                                <p>
                                    “It was a pleasure to work with Jaydon. He is very dedicated and professional.
                                    He worked very hard to satisfy our requirements and the communication was great.”
                                </p>

                                <div class="client-basicinfo">
                                    <h6>John Doe</h6>
                                    <!-- <a href="#">www.yourwebsite.zt</a> -->
                                </div>

                            </div>
                        </div>

                        <div class="item">
                            <div class="client-content">
                                <h3>What Our Clients are saying</h3>
                                <p>
                                    “It was a pleasure to work with Jaydon. He is very dedicated and professional.
                                    He worked very hard to satisfy our requirements and the communication was great.”

                                </p>

                                <div class="client-basicinfo">
                                    <h6>John Doe</h6>
                                    <!-- <a href="#">www.yourwebsite.zt</a> -->
                                </div>

                            </div>
                        </div>

                        <div class="item">
                            <div class="client-content">
                                <h3>What Our Clients are saying</h3>
                                <p>
                                    “It was a pleasure to work with Jaydon. He is very dedicated and professional.
                                    He worked very hard to satisfy our requirements and the communication was great.”
                                </p>

                                <div class="client-basicinfo">
                                    <h6>John Doe</h6>
                                    <!-- <a href="#">www.yourwebsite.zt</a> -->
                                </div>

                            </div>
                        </div>



                    </div>

                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                    </ol>

                </div>



            </div>

        </div>
    </div> <!-- /container -->
</section>