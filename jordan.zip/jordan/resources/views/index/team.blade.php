<section id="team" class="sections lightbg">
    <div class="container text-center">
        <div class="heading-content text-center">

            <h3>Our Team Members</h3>

            <div class="separator"></div>

            <p>Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim </p>

        </div>
        <!-- Example row of columns -->
        <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="main-team">
                    <div class="team-details">

                        <img src="assets/images/team-img.jpg" alt="" />
                        <div class="team-overlay"></div>

                        <div class="social">
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-linkedin"></i></a>
                        </div>

                    </div>

                    <div class="members-info">
                        <h4>Mitchell Anderson</h4>
                        <h6>Creative Director</h6>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="main-team">
                    <div class="team-details">

                        <img src="assets/images/team-img.jpg" alt="" />
                        <div class="team-overlay"></div>

                        <div class="social">
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-linkedin"></i></a>
                        </div>

                    </div>

                    <div class="members-info">
                        <h4>Mitchell Anderson</h4>
                        <h6>Creative Director</h6>
                    </div>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="main-team">
                    <div class="team-details">

                        <img src="assets/images/team-img.jpg" alt="" />
                        <div class="team-overlay"></div>

                        <div class="social">
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-linkedin"></i></a>
                        </div>

                    </div>

                    <div class="members-info">
                        <h4>Mitchell Anderson</h4>
                        <h6>Creative Director</h6>
                    </div>
                </div>
            </div>




        </div>
    </div> <!-- /container -->
</section>