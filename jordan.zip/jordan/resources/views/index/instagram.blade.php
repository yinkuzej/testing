<section id="twitter" class="sections different-bg">
    <div class="container text-center">

        <!-- Example row of columns -->
        <div class="row">
            <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12">
                <div class="twitter-content">
                    <h5>LATEST FROM INSTAGRAM</h5>
                    @if(!empty($instagram_images))
                        <div class="instagram-content">
                        @foreach($instagram_images as $row)
                            <img src="{{$row}}">
                            @endforeach
                        </div>
                    @endif
                    <p>Snap Perfection did an amazing job at our event, they exceeded our expectations!</p>
                    <a target="_blank" href="#">Follow Us</a>
                </div>
            </div>


        </div>

    </div> <!-- /container -->
</section>