<section id="price" class="price sections">


    <div class="head_title text-center">
        <h1>Service Packages</h1>
        <p>Don’t see a service package that suits your needs? Message us with further details of your event/party, and we will get back to you!</p>
    </div>
    <!-- Example row of columns -->
    <div class="cd-pricing-container cd-has-margins">

        <ul class="cd-pricing-list cd-bounce-invert">
            <li>
                <ul class="cd-pricing-wrapper">
                    <li data-type="monthly" class="is-visible">
                        <!-- <img src="assets/images/package1.png" alt=""> -->
                        <header class="cd-pricing-header bronze-head">
                            <h2>Standard Package</h2>

                            <div class="cd-price">
                                <span class="cd-currency">$</span>
                                <span class="cd-value">575.00</span>
                            </div>
                        </header> <!-- .cd-pricing-header -->

                        <div class="cd-pricing-body">
                            <ul class="cd-pricing-features">
                                <li><em><i class="fa fa-clock-o" aria-hidden="true"></i></em>2 Hours</li>
                                <li><em><i class="fa fa-camera" aria-hidden="true"></i></em>Unlimited Unique Props</li>
                                <li><em><i class="fa fa-cog" aria-hidden="true"></i></em>Customized Template</li>
                                <li><em><i class="fa fa-picture-o" aria-hidden="true"></i></em>Unlimited 4x6 Photo Prints</li>
                                <li><em><i class="fa fa-thumbs-o-up" aria-hidden="true"></i></em>Beautiful Backdrops</li>
                                <li><em><i class="fa fa-user" aria-hidden="true"></i></em>Professional Booth Attendant</li>
                                <li><em><i class="fa fa-book" aria-hidden="true"></i></em>Personalized Event Scrapbook</li>
                                <li><em><i class="fa fa-envelope-o" aria-hidden="true"></i></em>All Photos Sent by Email</li>
                            </ul>
                        </div> <!-- .cd-pricing-body -->

                        <footer class="cd-pricing-footer">
                            <a class="cd-select" href="#">Purchase</a>
                        </footer>  <!-- .cd-pricing-footer -->
                    </li>
                </ul> <!-- .cd-pricing-wrapper -->
            </li>

            <li class="cd-popular">
                <ul class="cd-pricing-wrapper">
                    <li data-type="monthly" class="is-visible">
                        <header class="cd-pricing-header silver-head">
                            <h2>Premium package</h2>
                            <div class="cd-price">
                                <span class="cd-currency">$</span>
                                <span class="cd-value">700.00</span>
                            </div>
                        </header> <!-- .cd-pricing-header -->

                        <div class="cd-pricing-body">
                            <ul class="cd-pricing-features">
                                <li><em><i class="fa fa-clock-o" aria-hidden="true"></i></em>3 Hours</li>
                                <li><em><i class="fa fa-camera" aria-hidden="true"></i></em>Unlimited Unique Props</li>
                                <li><em><i class="fa fa-cog" aria-hidden="true"></i></em>Customized Template</li>
                                <li><em><i class="fa fa-picture-o" aria-hidden="true"></i></em>Unlimited 4x6 Photo Prints</li>
                                <li><em><i class="fa fa-thumbs-o-up" aria-hidden="true"></i></em>Beautiful Backdrops</li>
                                <li><em><i class="fa fa-user" aria-hidden="true"></i></em>Professional Booth Attendant</li>
                                <li><em><i class="fa fa-book" aria-hidden="true"></i></em>Personalized Event Scrapbook</li>
                                <li><em><i class="fa fa-envelope-o" aria-hidden="true"></i></em>All Photos Sent by Email</li>
                            </ul>
                        </div> <!-- .cd-pricing-body -->

                        <footer class="cd-pricing-footer">
                            <a class="cd-select" href="#">Purchase</a>
                        </footer>  <!-- .cd-pricing-footer -->
                    </li>
                </ul> <!-- .cd-pricing-wrapper -->
            </li>

            <li>
                <ul class="cd-pricing-wrapper">
                    <li data-type="monthly" class="is-visible">
                        <header class="cd-pricing-header gold-head">
                            <h2>Executive Package</h2>

                            <div class="cd-price">
                                <span class="cd-currency">$</span>
                                <span class="cd-value">825.00</span>
                            </div>
                        </header> <!-- .cd-pricing-header -->

                        <div class="cd-pricing-body">
                            <ul class="cd-pricing-features">
                                <li><em><i class="fa fa-clock-o" aria-hidden="true"></i></em>4 Hours</li>
                                <li><em><i class="fa fa-camera" aria-hidden="true"></i></em>Unlimited Unique Props</li>
                                <li><em><i class="fa fa-cog" aria-hidden="true"></i></em>Customized Template</li>
                                <li><em><i class="fa fa-picture-o" aria-hidden="true"></i></em>Unlimited 4x6 Photo Prints</li>
                                <li><em><i class="fa fa-thumbs-o-up" aria-hidden="true"></i></em>Beautiful Backdrops</li>
                                <li><em><i class="fa fa-user" aria-hidden="true"></i></em>Professional Booth Attendant</li>
                                <li><em><i class="fa fa-book" aria-hidden="true"></i></em>Personalized Event Scrapbook</li>
                                <li><em><i class="fa fa-envelope-o" aria-hidden="true"></i></em>All Photos Sent by Email</li>
                            </ul>
                        </div> <!-- .cd-pricing-body -->

                        <footer class="cd-pricing-footer">
                            <a class="cd-select" href="#">Purchase</a>
                        </footer>  <!-- .cd-pricing-footer -->
                    </li>
                </ul> <!-- .cd-pricing-wrapper -->
            </li>
        </ul> <!-- .cd-pricing-list -->
    </div> <!-- .cd-pricing-container -->

</section>