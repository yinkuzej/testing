@extends('../../layouts.app')

@section('header')
    @if(session('success'))
        <div class="alert alert-success">
            <strong>Success!</strong> {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-error">
            <strong>oops!</strong> {{ session('error') }}
        </div>
    @endif
    @foreach ($testimonies as $testimony)
        <blockquote class="blockquote">
            <p class="mb-0">{{ $testimony->message }}</p>
            <footer class="blockquote-footer"> By {{ $testimony->name }} at <cite
                        title="Source Title">{{ $testimony->published_at }}</cite></footer>
        </blockquote>
    @endforeach
    {{ $testimonies->links() }}
@stop