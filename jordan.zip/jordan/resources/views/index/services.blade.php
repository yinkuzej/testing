<section id="service" class="sections">
    <div class="container text-center">
        <div class="heading-content2">

            <h4>Services We provide</h4>

            <p>
                We work with you to ensure perfection that the photobooth is unique. Our booths are equipped with the best DSLR cameras; touch screen monitors, and printers that produce high quality photo strips in seconds.<br/>

                We offer high quality props, unlimited photos and exceptional customer services. Our Photobooths are great for Weddings, Anniversaries, Birthdays, Corporate Events, Holiday Parties, Appreciation Events, Graduations, Special School Events, Baby Showers, Engagement Parties, Sweet 16's, Reunions, Fundraisers and any other perfect event you can think of!
            </p>

        </div>
    </div>
</section>