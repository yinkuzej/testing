<section id="project" class="sections">
    <div class="container text-center">

        <div class="heading-content text-center">

            <h3 class="backdrops-heading">Backdrops</h3>

            <div class="separator"></div>

            <p>We have a perfect selection of backdrops available for your event! If you see a backdrop you like that isn't available we can order it in for your occasion!
            </p>

        </div>
        <!-- Example row of columns -->
        <div class="row">

            <div class="col-md-3 col-sm-6 col-xs-12">

                <div class="project-item">
                    <img src="assets/images/project/1.png" alt="" />

                    <div class="project-overlay"></div>
                    <div class="project-content">
                        <h5>carat</h5>
                        <div class="project-separator"></div>
                        <h6>backdrop</h6>
                    </div>
                </div>

            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="project-item">
                    <img src="assets/images/project/2.png" alt="" />

                    <div class="project-overlay"></div>
                    <div class="project-content">
                        <h5>vegas</h5>
                        <div class="project-separator"></div>
                        <h6>backdrop</h6>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="project-item">
                    <img src="assets/images/project/3.png" alt="" />

                    <div class="project-overlay"></div>
                    <div class="project-content">
                        <h5>unicorn</h5>
                        <div class="project-separator"></div>
                        <h6>backdrop</h6>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="project-item">
                    <img src="assets/images/project/4.png" alt="" />

                    <div class="project-overlay"></div>
                    <div class="project-content">
                        <h5>diamond</h5>
                        <div class="project-separator"></div>
                        <h6>backdrop</h6>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="project-item">
                    <img src="assets/images/project/5.png" alt="" />

                    <div class="project-overlay"></div>
                    <div class="project-content">
                        <h5>opal</h5>
                        <div class="project-separator"></div>
                        <h6>backdrop</h6>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="project-item">
                    <img src="assets/images/project/6.png" alt="" />

                    <div class="project-overlay"></div>
                    <div class="project-content">
                        <h5>rose</h5>
                        <div class="project-separator"></div>
                        <h6>backdrop</h6>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="project-item">
                    <img src="assets/images/project/7.png" alt="" />

                    <div class="project-overlay"></div>
                    <div class="project-content">
                        <h5>ruby</h5>
                        <div class="project-separator"></div>
                        <h6>backdrop</h6>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="project-item">
                    <img src="assets/images/project/8.png" alt="" />

                    <div class="project-overlay"></div>
                    <div class="project-content">
                        <h5>silver</h5>
                        <div class="project-separator"></div>
                        <h6>backdrop</h6>
                    </div>
                </div>
            </div>

        </div>

        <div class="project-button">
            <a href="#contact"><button class="btn btn-default">inquire now<span><i class="fa fa-long-arrow-right"></i></span></button></a>
        </div>

    </div> <!-- /container -->
</section>