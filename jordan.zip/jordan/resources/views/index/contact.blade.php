<section id="contact" class="sections lightbg">
    <div class="container">

        <div class="heading-content text-center">
            <div class="heading-title">
                <h3>Contact</h3>
            </div>

        </div>

        @if(session()->has('message'))
            <div class="alert alert-success">
                {{ session()->get('message') }}
            </div>
        @else
            <div class="row Normal" style="margin:0 auto;">
                <h3 class="  normal"><span class="required">*</span> Interested In:</h3>
                <input type="text" id="your_input" name="your_input"/>

                <select name="eventType">
                    <option value=""> --</option>
                    <option value="sporting_event">Sporting Event</option>
                    <option value="charity_event" selected>Charity Event</option>
                </select>

                <h1 class="you-chose">You chose <img src="/img/calendar.png" align="absmiddle">
                    <strong>12/16/2017</strong> as your event date</h1>
                <div id="main_form" style="display: none;">
                    <span>*</span>Required


                    <form id="contactForm" class="ui fluid form" role="form" action="{{ asset('/form/contact/submit') }}"
                          method="post">

                        {{ csrf_field() }}
                        <input type="hidden" name="form_type" value="contact">

                        <div class="">
                            <span class="required">*</span> First + last name


                            <input type="text" id="first_name" name="first_name" >
                            <input type="text" id="last_name" name="last_name" >
                        </div>

                        <div class="">
                            <span class="required">*</span> Your phone number?
                            <input type="tel" id="phone_number" name="phone_number" >
                        </div>

                        <div class="">
                            <span class="required">*</span> Your Email Address
                            <input type="email" id="email" name="email" >
                        </div>

                        <div class="">
                            <span class="required">*</span> What city is your event taking place in?
                            <input type="text" id="city" name="city" >
                        </div>
                        <div class="">
                            <span class="required">*</span> Chat with us! Tell us about your event, who you are, what you do, what you're looking for in a photobooth!
                            <textarea  id="message" name="message" ></textarea>
                        </div>

                        <div class="">
                            <span class="required">*</span>What time should the booth start?
                            <select id="start_hour" name="start_hour">
                                <option value=""> -- </option>
                                @for ($i =1; $i <= 12; $i++)
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <select id="start_min" name="start_min">
                                <option value=""> -- </option>
                                <option value="00">00</option>
                                <option value="01">01</option>
                                <option value="02">02</option>
                                <option value="03">03</option>
                                <option value="04">04</option>
                                <option value="05">05</option>
                                <option value="06">06</option>
                                <option value="07">07</option>
                                <option value="08">08</option>
                                <option value="09">09</option>
                                @for ($i =10; $i < 60; $i++)
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <select id="start_ampm" name="start_ampm">
                                <option value=""> -- </option>
                                <option value="am">AM</option>
                                <option value="pm">PM</option>
                            </select>
                        </div>

                        <div class="">
                            <span class="required">*</span>What time should the booth end?
                            <select id="end_hour" name="end_hour">
                                <option value=""> -- </option>
                                @for ($i =1; $i <= 12; $i++)
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <select id="end_min" name="end_min">
                                <option value=""> -- </option>
                                <option value="00">00</option>
                                <option value="01">01</option>
                                <option value="02">02</option>
                                <option value="03">03</option>
                                <option value="04">04</option>
                                <option value="05">05</option>
                                <option value="06">06</option>
                                <option value="07">07</option>
                                <option value="08">08</option>
                                <option value="09">09</option>
                                @for ($i =10; $i < 60; $i++)
                                    <option value="{{$i}}">{{$i}}</option>
                                @endfor
                            </select>
                            <select id="end_ampm" name="end_ampm">
                                <option value=""> -- </option>
                                <option value="am">AM</option>
                                <option value="pm">PM</option>
                            </select>
                        </div>


                        <div class="">
                            <span class="required">*</span> Event Name:
                            <input type="text" id="event_name" name="event_name" >
                        </div>

                        <div class="">
                            <span class="required">*</span> Event Venue Name:
                            <input type="text" id="event_venue_name" name="event_venue_name" >
                        </div>

                        <div class="">
                            <span class="required">*</span> How did you hear about us?
                            <select id="how_did_you_hear" name="how_did_you_hear">
                                <option value=""> -- </option>
                                <option value="Google">Google</option>
                                <option value="Facebook">Facebook</option>
                                <option value="Facebook Ad">Facebook Ad</option>
                                <option value="Instagram">Instagram</option>
                                <option value="We saw you at an event">We saw you at an event</option>
                                <option value="Referral from a friend">Referral from a friend</option>
                                <option value="Other">Other </option>
                            </select>
                            <textarea id="other" name="other" cols="45" rows="2"></textarea>
                        </div>

                        <div class="">
                            <span class="required">*</span> Is your event outdoors
                            <select id="event_outdoor" name="event_outdoor">
                                <option value=""> -- </option>
                                <option value="No">No</option>
                                <option value="Yes">Yes</option>
                            </select>
                        </div>

                        <button id="submitBtn" type="submit" class="ui button">Submit</button>
                    </form>
                </div>
            </div>
        @endif
    </div>
</section>