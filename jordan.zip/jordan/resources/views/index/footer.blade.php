<div class="scroll-top">

    <div class="scrollup">
        <i class="fa fa-angle-double-up"></i>
    </div>

</div>

<footer class="copyright-footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="copyright text-center">
                    <p>Made with <i class="fa fa-heart"></i> by <a target="_blank" href="#">Quill Design Co</a> 2017. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer>