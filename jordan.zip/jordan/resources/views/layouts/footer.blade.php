<footer class="footer">
    <!--footer navbar -->
    <div class="container footer-middle">
        <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
            <h3> Lorem Ipsum </h3>
            <ul>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
            </ul>
        </div>
        <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
            <h3> Lorem Ipsum </h3>
            <ul>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
            </ul>
        </div>
        <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
            <h3> Lorem Ipsum </h3>
            <ul>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
            </ul>
        </div>
        <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
            <h3> Lorem Ipsum </h3>
            <ul>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
            </ul>
        </div>
        <div class="col-lg-3  col-md-3 col-sm-6 col-xs-12 ">
            <h3> Lorem Ipsum </h3>
            <ul>
                <li>
                    <div class="input-append newsletter-box text-center">
                        <input type="text" class="full text-center" placeholder="Email ">
                        <button class="btn  bg-gray" type="button"> Lorem ipsum <i class="fa fa-long-arrow-right"> </i>
                        </button>
                    </div>
                </li>
            </ul>
            <ul class="social">
                <li><a href="#"> <i class=" fa fa-facebook">   </i> </a></li>
                <li><a href="#"> <i class="fa fa-twitter">   </i> </a></li>
                <li><a href="#"> <i class="fa fa-google-plus">   </i> </a></li>
                <li><a href="#"> <i class="fa fa-pinterest">   </i> </a></li>
                <li><a href="#"> <i class="fa fa-youtube">   </i> </a></li>
            </ul>
        </div>
    </div>
    <!--/.row-->
    <div class="container footer-bottom">
        <div class="container">
            <p class="pull-left"> Copyright © NCCG 2016. All right reserved. </p>
            <div class="pull-right">
                <ul class="nav nav-pills payments">
                    <li><i class="fa fa-cc-visa"></i></li>
                    <li><i class="fa fa-cc-mastercard"></i></li>
                    <li><i class="fa fa-cc-amex"></i></li>
                    <li><i class="fa fa-cc-paypal"></i></li>
                </ul>
            </div>
        </div>
    </div>
</footer>