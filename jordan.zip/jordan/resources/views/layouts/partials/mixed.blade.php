<!-- Bootstrap core CSS -->
<link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet">
{{--<link href="{{ asset('css/bootstrap-responsive.min.css') }}" rel="stylesheet">--}}
<link href="{{ asset('css/flipclock.css') }}" rel="stylesheet">
<link href="{{ asset('css/jquery-ui.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/fullcalendar.css') }}" rel="stylesheet">
<link href="{{ asset('css/fullcalendar.print.min.css') }}" rel="stylesheet" media="print">
<link href="{{ asset('css/skin.css') }}" rel="stylesheet">
<link href="{{ asset('assets/semantic-ui/semantic.css') }}" rel="stylesheet">
<link href="{{ asset('css/app.css') }}" rel="stylesheet">
{{--<link href="{{ asset('css/semantic.css') }}" rel="stylesheet">--}}


<script src="{{ asset('js/jquery-3.1.1.min.js') }}"></script>
<script src="{{ asset('js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('js/moment.min.js') }}"></script>
<script src="{{ asset('js/fullcalendar.js') }}"></script>
<script src="{{ asset('js/flipclock.js') }}"></script>
<script src="{{ asset('js/jquery.matchHeight.js') }}"></script>
<script src="{{ asset('js/jquery.slides.min.js') }}"></script>

<script src="{{ asset('js/skin.js') }}"></script>
<script src="{{ asset('assets/semantic-ui/semantic.js') }}"></script>
<script>

    $(function () {
        $(window).scroll(function () {

            if ($(document).scrollTop() > 150 && $(window).width() > 767) {
                $('.navbar').addClass('shrink');
            }
            else {
                $('.navbar').removeClass('shrink');
            }
        });

    });
</script>