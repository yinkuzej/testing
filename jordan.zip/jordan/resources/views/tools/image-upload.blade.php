<div class="panel panel-primary">
    <div class="panel-heading"><h2>Laravel 5.3 Image Upload with Validation example</h2></div>
    <div class="panel-body">

        @if (count($errors) > 0)
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        @if ($message = Session::get('success'))
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>{{ $message }}</strong>
            </div>
            <img src="/images/{{ Session::get('path') }}">
        @endif

        <form action="{{ url('image-upload') }}" enctype="multipart/form-data" method="POST">
            {{ csrf_field() }}
            <div class="row">
                <div class="col-md-12">
                    <input type="file" name="image[]" accept="image/*" id="pics" multiple="" />
                </div>

                <div class="col-md-12">
                    <button type="submit" class="btn btn-success">Upload</button>
                </div>
            </div>
            <div class="row" id="uploaderFiles">

                <div class="col-lg-12">
                    <h1 class="page-header">Thumbnail Preview</h1>
                </div>
                <div class="col-lg-3 col-md-4 col-xs-6 thumb">
                    <a class="thumbnail" href="#">
                        <img class="img-responsive" src="http://placehold.it/400x300" alt="">
                    </a>
                </div>

            </div>
            <script type="text/javascript">
                $(function () {
                    var tmpl = '<div class="col-lg-3 col-md-4 col-xs-6 thumb"><a class="thumbnail" href="#"><img class="img-responsive" src="#url#" alt=""></a></div>',
                        $gallery = $("#gallery"), $galleryImg = $("#galleryImg"),
                        $uploaderInput = $("#pics"),
                        $uploaderFiles = $("#uploaderFiles")
                        ;

                    $uploaderInput.on("change", function (e) {
                        var src, url = window.URL || window.webkitURL || window.mozURL, files = e.target.files;
                        for (var i = 0, len = files.length; i < len; ++i) {
                            var file = files[i];

                            if (url) {
                                src = url.createObjectURL(file);
                            } else {
                                src = e.target.result;
                            }

                            $uploaderFiles.append($(tmpl.replace('#url#', src)));
                        }
                    });
                    $uploaderFiles.on("click", "li", function () {
                        $galleryImg.attr("style", this.getAttribute("style"));
                        $gallery.fadeIn(100);
                    });
                    $gallery.on("click", function () {
                        $gallery.fadeOut(100);
                    });
                });
            </script>
        </form>

    </div>
</div>