@extends('layouts.app')

<!-- Main Content -->
@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Reset Password</div>
                <div class="panel-body">
                    @if (session('success'))
                            <div class="ui positive  message transition hidden">
                                <i class="close icon"></i>
                                <div class="header">Reset Password </div>
                                <p>{{ session('success') }}</p>
                            </div>
                            <div class="ui positive  message transition ">
                                <i class="close icon"></i>
                                <div class="header">Reset Password </div>
                                <p>{{ session('success') }}</p>
                            </div>
                            <script>
                                $('.message .close')
                                    .on('click', function() {
                                        $(this)
                                            .closest('.message')
                                            .transition('fade')
                                        ;
                                    })
                                ;
                            </script>
                    @endif

                    <form class="form-horizontal" role="form" method="POST" action="{{ url('/password/email') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">


                                @if(\Cartalyst\Sentinel\Laravel\Facades\Sentinel::Check() && Sentinel::getUser()->reg_from_social_media == 'Y')
                                <input id="email" type="email" class="form-control" name="email" value="{{ Sentinel::getUser()->email }}" required>
                                @else
                                    <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required>
                                @endif








                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Send Password Reset Link
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
