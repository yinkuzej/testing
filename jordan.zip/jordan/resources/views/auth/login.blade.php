@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Login</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="/login">
                        {{ csrf_field() }}

                        @if (session('error'))
                        <div class="ui negative  message transition hidden">
                            <i class="close icon"></i>
                            <div class="header">Welcome back! </div>
                            <p>{{ session('error') }}</p>
                        </div>
                            <div class="ui negative  message transition ">
                            <i class="close icon"></i>
                            <div class="header">Sorry! </div>
                            <p>{{ session('error') }}</p>
                        </div>
                        <script>
                            $('.message .close')
                            .on('click', function() {
                            $(this)
                            .closest('.message')
                            .transition('fade')
                            ;
                            })
                            ;
                        </script>
                        @endif
                        @if (session('success'))
                            <div class="ui info  message transition hidden">
                                <i class="close icon"></i>
                                <p>{{ session('success') }}</p>
                            </div>
                            <div class="ui info  message transition ">
                                <i class="close icon"></i>
                                <p>{{ session('success') }}</p>
                            </div>
                            <script>
                                $('.message .close')
                                    .on('click', function() {
                                        $(this)
                                            .closest('.message')
                                            .transition('fade')
                                        ;
                                    })
                                ;
                            </script>
                        @endif

                        <div class="socials center">
                            {{--<h2 align="center">Login with</h2>--}}
                            <a class="ui circular facebook icon button" href="{{ url('/login/facebook') }}"  title="Login on Facebook"> <i class="facebook icon"></i></a>
                            <a class="ui circular twitter icon button" href="{{ url('/login/twitter') }}" title="Login on Twitter"> <i class="twitter icon"></i></a>
                            <a class="ui circular google plus icon button" href="{{ url('/login/google') }}" title="Login on Google+"> <i class="google plus icon"></i></a>
                        </div>

                        <div class="ui horizontal divider">
                            Or
                        </div>
                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember"> Remember Me
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Login
                                </button>

                                <a class="btn btn-link" href="{{ url('/password/reset') }}">
                                    Forgot Your Password?
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
