<?php $__env->startSection('content'); ?>
<br><br><br><br><br><br><br><br>

<div class="ui fluid input icon">
    <div class="ui icon input">
        <input class="prompt" id="tracts-search-input" type="text" value="<?php echo e((!empty($keywords)? $keywords :'')); ?>" placeholder="Search Tracts By Title">
        <i class="search icon"></i>
    </div>
</div>
<div class="page-header">
    <?php if(!empty($keywords)): ?>
        <h2 class="tracts-keywords">Tracts like "<em><?php echo e($keywords); ?></em>"</h2>
    <?php else: ?>
        <h2 class="tracts-keywords">All Tracts</h2>
    <?php endif; ?>
</div>


    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Title</th>
                    <th class="text-right">OPTIONS</th>
                </tr>
                </thead>

                <tbody id="results">

                <?php $__currentLoopData = $tracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($tract->title); ?></td>

                        <td class="text-right">
                            <input type="checkbox" <?php echo e(($tract->display =='Y'?'checked':'' )); ?> data-toggle="toggle" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="danger">
                            <a class="btn btn-primary" href="<?php echo e(asset('/admin/tract/'.$tract->id)); ?>">View</a>
                            <a class="btn btn-warning " href="<?php echo e(asset('/admin/tract/'.$tract->id.'/edit')); ?>">Edit</a>
                            <form action="/admin/tract/<?php echo e($tract->id); ?>/delete" method="DELETE" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><button class="btn btn-danger" type="submit">Delete</button></form>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

            <a class="btn btn-success" href="<?php echo e(asset('/admin/tract/create')); ?>">Create</a>
        </div>
    </div>
<div class="tracts-nav">
    <?php echo e($tracts->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>