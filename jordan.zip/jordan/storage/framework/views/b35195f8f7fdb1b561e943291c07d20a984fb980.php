<section id="about" class="sections">

    <div class="heading-content text-center">

        <h3>About us</h3>

        <div class="separator"></div>

        <p>Snap Perfection Photobooth is a modern and professional photobooth company that is sure to be the life of any party! From Weddings to Birthdays, Baby Showers to Corporate Events… We do it all!
            Unlike the regular old fashioned photobooth that can squeeze in a maximum of 3 people… We have a sleek and elegant booth that is open concept and fully equipped with professional photography equipment.
            Simply explain your event so we can customize your photo template, choose a backdrop and some props and you’re ready for your close-up!
            We are proud to offer an enormous selection of props and backdrops that are sure to be the cherry on top of your already perfect photos.
        </p>

    </div>

    <div class="about-bg">
        <div class="container">


            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-6">
                    <div class="about-content">

                        <h3>We Are the best</h3>
                        <p class="about-text">Snap Perfection Photobooth is Winnipeg's "go-to" provider of comprehensive Photobooth Services.</p>
                        <p class="about-text">Our Booth features an elegant open-air design, accompanied by professional lighting and a leading edge DSLR camera. Choose from our wide variety of beautiful backdrops that are sure to accentuate any event, and leave your guests with memories of a lifetime as their photos are printed in seconds.</p>


                        <a target="_blank" href="#"><button class="btn btn-default abt-btn">BOOK NOW<span><i class="fa fa-long-arrow-right"></i></span></button></a>
                    </div>
                </div>

                <div class="col-md-6 col-sm-6 col-xs-6">
                    <div class="about-img">
                        <img src="assets/images/booth-img" alt="" />
                    </div>
                </div>

            </div>
        </div>
    </div>

</section>