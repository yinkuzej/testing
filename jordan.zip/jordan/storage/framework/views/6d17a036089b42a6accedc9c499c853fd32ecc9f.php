<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <title>RCCG</title>


    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">


    <!-- Custom CSS -->
    <link href="<?php echo e(asset('backend/css/sb-admin.css')); ?>" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="<?php echo e(asset('backend/css/plugins/morris.css')); ?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('backend/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('backend/css/bootstrap-toggle.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/css/bootstrap-colorpicker.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/semantic-ui/semantic.min.css')); ?>" rel="stylesheet">


    <script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>

    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    <script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/semantic-ui/semantic.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/bootstrap-toggle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/bootstrap-colorpicker.min.js')); ?>"></script>
    <script>
        url = '<?php echo e(Request::server ("SERVER_NAME")); ?>';

    </script>
    <script src="<?php echo e(asset('js/skin.js')); ?>"></script>

    <![endif]-->

</head>

<body>

<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/admin">RCCG Dashboard</a>

        </div>
        <!-- Top Menu Items -->
        <ul class="nav navbar-right top-nav">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
                            class="fa fa-user"></i> <?= Sentinel::getUser()->first_name; ?> <b
                            class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li>
                        <a href="#"><i class="fa fa-fw fa-user"></i> Profile</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-fw fa-envelope"></i> Inbox</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-fw fa-gear"></i> Settings</a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a href="<?php echo e(url('/admin/logout')); ?>"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <i class="fa fa-fw fa-power-off"></i> Log Out
                        </a>

                        <form id="logout-form" action="<?php echo e(url('/admin/logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                </ul>
            </li>
        </ul>
        <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav side-nav">
                <li class="active">
                    <a href="/admin"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                </li>
                <li>
                    <a href="javascript:;" data-toggle="collapse" data-target="#forms"><i class="fa fa-info-circle"></i>
                        Forms <i class="fa fa-fw fa-caret-down"></i></a>

                    <ul id="forms" class="collapse">
                        <li>
                            <a href="/admin/contact-form"><i class="fa fa-fw fa-file"></i> Contact Us </a>
                        </li>
                        
                        
                        
                        
                        
                        
                        <li>
                            <a href="/admin/prayer-form"><i class="fa fa-fw fa-file"></i> Prayer Requests </a>
                        </li>
                    </ul>

                </li>
                <li>
                    <a href="/admin/testimonies"><i class="fa fa-fw fa-file"></i> Testimonies </a>
                </li>
                <li>
                    <a href="/admin/blogs"><i class="fa fa-fw fa-file"></i> Blogs </a>
                </li>
                <li>
                    <a href="/admin/pastor/settings"><i class="fa fa-fw fa-dashboard"></i>Pastor's Settings</a>
                </li>
                <li>
                    <a href="/admin/calendar_events"><i class="fa fa-fw fa-dashboard"></i>Calendar</a>
                </li>
                <li>
                    <a href="/admin/faq"><i class="fa fa-fw fa-dashboard"></i>FAQ</a>
                </li>
                <li>
                    <a href="/admin/tracts"><i class="fa fa-fw fa-dashboard"></i>Tracts</a>
                </li>
                <li>
                    <a href="/admin/general/settings"><i class="fa fa-fw fa-dashboard"></i>General Settings</a>
                </li>
                <li>
                    <a href="/admin/workers"><i class="fa fa-fw fa-dashboard"></i>All Workers</a>
                </li>
                <li>
                    <a href="/admin/users"><i class="fa fa-fw fa-dashboard"></i>All Users</a>
                </li>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </nav>

    <div id="page-wrapper">

        <div class="container-fluid">

            <?php echo $__env->yieldContent('content'); ?>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->


<!-- /#wrapper -->

    <!-- jQuery -->


<!-- Bootstrap Core JavaScript -->

    <!-- Morris Charts JavaScript -->
    
    
    


</body>

</html>
