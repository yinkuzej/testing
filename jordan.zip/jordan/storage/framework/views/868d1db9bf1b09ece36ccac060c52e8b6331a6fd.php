<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <h1>Testimony / Show </h1>
    </div>


    <div class="row">
        <div class="col-md-12">

            <form action="#">
                <div class="form-group">
                    <label for="title">Name</label>
                    <p class="form-control-static"><?php echo e($testimony->name); ?></p>
                </div>
                <div class="form-group">
                    <label for="start">Subject</label>
                    <p class="form-control-static"><?php echo e($testimony->subject); ?></p>
                </div>
                <div class="form-group">
                    <label for="end">Message</label>
                    <p class="form-control-static"><?php echo e($testimony->message); ?></p>
                </div>
                <div class="form-group">
                    <label for="end">Display on main site</label>
                    <p class="form-control-static"><?php echo e(($testimony->display == 'Y')?'Yes':'No'); ?></p>
                </div>
            </form>



            <a class="btn btn-default" href="<?php echo e(asset('/admin/testimonies')); ?>">Back</a>
            <a class="btn btn-warning" href="<?php echo e(asset('/admin/testimony/'.$testimony->id.'/edit')); ?>">Edit</a>
            <form action="/admin/testimony/<?php echo e($testimony->id); ?>/delete" method="DELETE" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><button class="btn btn-danger" type="submit">Delete</button></form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>