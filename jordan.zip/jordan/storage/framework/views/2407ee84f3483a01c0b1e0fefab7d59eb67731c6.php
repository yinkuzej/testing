<?php $__env->startSection('content'); ?>
    <br><br><br><br><br><br><br><br>

    <div class="ui fluid input icon">
        <div class="ui icon input">
            <input class="prompt" id="workers-search-input" type="text" value="<?php echo e((!empty($keywords)? $keywords :'')); ?>" placeholder="Search Worker By First or Last Name ">
            <i class="search icon"></i>
        </div>
    </div>
    <div class="row">
        <div class="page-header">
            <?php if(!empty($keywords)): ?>
                <h2 class="workers-keywords">Workers with name like "<em><?php echo e($keywords); ?></em>"</h2>
            <?php else: ?>
                <h2 class="workers-keywords">All Workers</h2>
            <?php endif; ?>
        </div>


        <div class="row">
    <div class="col-md-12">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                
                
                
                <th class="text-right">OPTIONS</th>
            </tr>
            </thead>

            <tbody id="results">

            <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(ucfirst(strtolower($worker->first_name)) .' '. ucfirst(strtolower($worker->last_name))); ?></td>
                    <td><?php echo e($worker->email); ?></td>
                    
                    
                    
                    

                    <td class="text-right">
                        <a class="btn btn-primary" href="<?php echo e(route('workers.show', $worker->id)); ?>">View</a>
                        <a class="btn btn-warning " href="<?php echo e(route('workers.edit', $worker->id)); ?>">Edit</a>
                        <a class="btn btn-warning " href="/admin/workers/<?php echo e($worker->id); ?>/permissions">Change Permissions</a>
                        <form action="<?php echo e(route('workers.destroy', $worker->id)); ?>" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><input type="hidden" name="_method" value="DELETE"><input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <button class="btn btn-danger" type="submit">Delete</button></form>
                    </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
        
        <div class="workers-nav">
            <?php echo e($workers->links()); ?>


        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>