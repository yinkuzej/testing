<?php $__env->startSection('content'); ?>
    <br><br><br><br><br><br><br><br>

    <div class="ui fluid input icon">
        <div class="ui icon input">
            <input class="prompt" id="testimonies-search-input" type="text" value="<?php echo e((!empty($keywords)? $keywords :'')); ?>" placeholder="Search Testimonies By User">
            <i class="search icon"></i>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <?php if(!empty($keywords)): ?>
                <h2 class="testimonies-keywords">Testimonies By "<em><?php echo e($keywords); ?></em>"</h2>
            <?php else: ?>
                <h2 class="testimonies-keywords">All Testimonies</h2>
            <?php endif; ?>
        </div>



            <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Subject</th>
                    <th>Testimony</th>
                    <th class="text-right">OPTIONS</th>
                </tr>
                </thead>

                <tbody id="results">

                <?php $__currentLoopData = $testimonies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($testimony->name); ?></td>
                        <td><?php echo e($testimony->subject); ?></td>
                        <td><?php echo e($testimony->message); ?></td>

                        <td class="text-right">
                            <input type="checkbox" <?php echo e(($testimony->display =='Y'?'checked':'' )); ?> data-toggle="toggle" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="danger">
                            <a class="btn btn-primary" href="<?php echo e(asset('/admin/testimony/'.$testimony->id)); ?>">View</a>
                            <a class="btn btn-warning " href="<?php echo e(asset('/admin/testimony/'.$testimony->id.'/edit')); ?>">Edit</a>
                            <form action="/admin/testimony/<?php echo e($testimony->id); ?>/delete" method="DELETE" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><button class="btn btn-danger" type="submit">Delete</button></form>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

            <a class="btn btn-success" href="<?php echo e(asset('/admin/testimony/create')); ?>">Create</a>
        </div>
    </div>
            <div class="testimony-nav">

            <?php echo e($testimonies->links()); ?>


            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>