<?php $__env->startSection('content'); ?>
    <br><br><br><br><br><br><br><br>

    <form class="ui form" method="post" action="/admin/workers/9/permissions">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <style type="text/css">
            .tg  {border-collapse:collapse;border-spacing:0;margin:0px auto;}
            .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;}
            .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;}
            .tg .tg-yw4l{vertical-align:top}
            @media  screen and (max-width: 767px) {.tg {width: auto !important;}.tg col {width: auto !important;}.tg-wrap {overflow-x: auto;-webkit-overflow-scrolling: touch;margin: auto 0px;}}</style>
        <div class="tg-wrap"><table class="tg">

                <tr>
                    <th class="tg-yw4l" colspan="3"><h2>Pastor's Settings</h2></th>
                </tr>
                <tr>
                    <td class="tg-yw4l">S/N</td>
                    <td class="tg-yw4l">Permissions</td>
                    <td class="tg-yw4l">Allow</td>
                </tr>
                <tr>
                    <td class="tg-yw4l">1</td>
                    <td class="tg-yw4l">Ability to update settings for pastor</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="pastorsettings.update" type="checkbox" value="true"<?php echo e(!empty($permissions['pastorsettings.update']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>


                <tr>
                    <th class="tg-yw4l" colspan="3"><h2>User's Permissions</h2></th>
                </tr>
                <tr>
                    <td class="tg-yw4l">S/N</td>
                    <td class="tg-yw4l">Permissions</td>
                    <td class="tg-yw4l">Allow</td>
                </tr>
                <tr>
                    <td class="tg-yw4l">1</td>
                    <td class="tg-yw4l">Ability to Create Users From the admin</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="user.create" type="checkbox" value="true" <?php echo e(!empty($permissions['user.create']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">2</td>
                    <td class="tg-yw4l">Ability to Delete Users From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="user.delete" type="checkbox" value="true"<?php echo e(!empty($permissions['user.delete']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">3</td>
                    <td class="tg-yw4l">Ability to Update Users From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="user.update" type="checkbox" value="true"<?php echo e(!empty($permissions['user.update']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">4</td>
                    <td class="tg-yw4l">Ability to Retrieve Users From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="user.select" type="checkbox" value="true"<?php echo e(!empty($permissions['user.select']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                    
                <tr>
                    <th class="tg-yw4l" colspan="3"><h2>Blog's Permissions</h2></th>
                </tr>
                <tr>
                    <td class="tg-yw4l">S/N</td>
                    <td class="tg-yw4l">Permissions</td>
                    <td class="tg-yw4l">Allow</td>
                </tr>
                <tr>
                    <td class="tg-yw4l">1</td>
                    <td class="tg-yw4l">Ability to Create Blogs From the admin</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="blog.create" type="checkbox" value="true"<?php echo e(!empty($permissions['blog.create']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">2</td>
                    <td class="tg-yw4l">Ability to Delete Blogs From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="blog.delete" type="checkbox" value="true"<?php echo e(!empty($permissions['blog.delete']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">3</td>
                    <td class="tg-yw4l">Ability to Update Blogs From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="blog.update" type="checkbox" value="true"<?php echo e(!empty($permissions['blog.update']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">4</td>
                    <td class="tg-yw4l">Ability to Retrieve Blogs From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="blog.select" type="checkbox" value="true"<?php echo e(!empty($permissions['blog.select']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>

                
                <tr>
                    <th class="tg-yw4l" colspan="3"><h2>Testimonies Permissions</h2></th>
                </tr>
                <tr>
                    <td class="tg-yw4l">S/N</td>
                    <td class="tg-yw4l">Permissions</td>
                    <td class="tg-yw4l">Allow</td>
                </tr>
                <tr>
                    <td class="tg-yw4l">1</td>
                    <td class="tg-yw4l">Ability to Create Testimonies From the admin</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="testimony.create" type="checkbox" value="true"<?php echo e(!empty($permissions['testimony.create']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">2</td>
                    <td class="tg-yw4l">Ability to Delete Testimonies From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="testimony.delete" type="checkbox" value="true"<?php echo e(!empty($permissions['testimony.delete']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">3</td>
                    <td class="tg-yw4l">Ability to Update Testimonies From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="testimony.update" type="checkbox" value="true"<?php echo e(!empty($permissions['testimony.update']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">4</td>
                    <td class="tg-yw4l">Ability to Retrieve Testimonies From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="testimony.select" type="checkbox" value="true"<?php echo e(!empty($permissions['testimony.select']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>


                
                <tr>
                    <th class="tg-yw4l" colspan="3"><h2>Frequently Asked Questions(FAQ) Permissions</h2></th>
                </tr>
                <tr>
                    <td class="tg-yw4l">S/N</td>
                    <td class="tg-yw4l">Permissions</td>
                    <td class="tg-yw4l">Allow</td>
                </tr>
                <tr>
                    <td class="tg-yw4l">1</td>
                    <td class="tg-yw4l">Ability to Create FAQ From the admin</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="faq.create" type="checkbox" value="true"<?php echo e(!empty($permissions['faq.create']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">2</td>
                    <td class="tg-yw4l">Ability to Delete FAQ From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="faq.delete" type="checkbox" value="true"<?php echo e(!empty($permissions['faq.delete']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">3</td>
                    <td class="tg-yw4l">Ability to Update FAQ From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="faq.update" type="checkbox" value="true"<?php echo e(!empty($permissions['faq.update']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">4</td>
                    <td class="tg-yw4l">Ability to Retrieve FAQ From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="faq.select" type="checkbox" value="true"<?php echo e(!empty($permissions['faq.select']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>



                
                <tr>
                    <th class="tg-yw4l" colspan="3"><h2>Calendar Events Permissions</h2></th>
                </tr>
                <tr>
                    <td class="tg-yw4l">S/N</td>
                    <td class="tg-yw4l">Permissions</td>
                    <td class="tg-yw4l">Allow</td>
                </tr>
                <tr>
                    <td class="tg-yw4l">1</td>
                    <td class="tg-yw4l">Ability to Create events From the admin</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="calendar.create" type="checkbox" value="true"<?php echo e(!empty($permissions['calendar.create']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">2</td>
                    <td class="tg-yw4l">Ability to Delete events From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="calendar.delete" type="checkbox" value="true"<?php echo e(!empty($permissions['calendar.delete']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">3</td>
                    <td class="tg-yw4l">Ability to Update events From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="calendar.update" type="checkbox" value="true"<?php echo e(!empty($permissions['calendar.update']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">4</td>
                    <td class="tg-yw4l">Ability to Retrieve events From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="calendar.select" type="checkbox" value="true"<?php echo e(!empty($permissions['calendar.select']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>


                
                <tr>
                    <th class="tg-yw4l" colspan="3"><h2>Workers Permissions</h2></th>
                </tr>
                <tr>
                    <td class="tg-yw4l">S/N</td>
                    <td class="tg-yw4l">Permissions</td>
                    <td class="tg-yw4l">Allow</td>
                </tr>
                <tr>
                    <td class="tg-yw4l">1</td>
                    <td class="tg-yw4l">Ability to Create workers From the admin</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="worker.create" type="checkbox" value="true"<?php echo e(!empty($permissions['worker.create']) ? 'checked  ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">2</td>
                    <td class="tg-yw4l">Ability to Delete worker From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="worker.delete" type="checkbox" value="true"<?php echo e(!empty($permissions['worker.delete']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">3</td>
                    <td class="tg-yw4l">Ability to Update workers From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="worker.update" type="checkbox" value="true"<?php echo e(!empty($permissions['worker.update']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">4</td>
                    <td class="tg-yw4l">Ability to Retrieve workers info From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="worker.select" type="checkbox" value="true"<?php echo e(!empty($permissions['worker.select']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>

                <tr>
                    <td class="tg-yw4l">5</td>
                    <td class="tg-yw4l">Ability to Retrieve workers info From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="worker.permissions" type="checkbox" value="true"<?php echo e(!empty($permissions['worker.permissions']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>

                
                <tr>
                    <th class="tg-yw4l" colspan="3"><h2>Contact Form Permissions</h2></th>
                </tr>
                <tr>
                    <td class="tg-yw4l">S/N</td>
                    <td class="tg-yw4l">Permissions</td>
                    <td class="tg-yw4l">Allow</td>
                </tr>
                <tr>
                    <td class="tg-yw4l">1</td>
                    <td class="tg-yw4l">Ability to view contact forms From the backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="contactform.view" type="checkbox" value="true"<?php echo e(!empty($permissions['contactform.view']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">2</td>
                    <td class="tg-yw4l">Ability to Delete contact forms From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="contactform.delete" type="checkbox" value="true"<?php echo e(!empty($permissions['contactform.delete']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>

                
                <tr>
                    <th class="tg-yw4l" colspan="3"><h2>Feedback Form Permissions</h2></th>
                </tr>
                <tr>
                    <td class="tg-yw4l">S/N</td>
                    <td class="tg-yw4l">Permissions</td>
                    <td class="tg-yw4l">Allow</td>
                </tr>
                <tr>
                    <td class="tg-yw4l">1</td>
                    <td class="tg-yw4l">Ability to view feedback forms From the backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="feedbackform.view" type="checkbox" value="true"<?php echo e(!empty($permissions['feedbackform.view']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">2</td>
                    <td class="tg-yw4l">Ability to Delete feedback forms From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="feedbackform.delete" type="checkbox" value="true"<?php echo e(!empty($permissions['feedbackform.delete']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>

                
                <tr>
                    <th class="tg-yw4l" colspan="3"><h2>Ask The Pastor Form Permissions</h2></th>
                </tr>
                <tr>
                    <td class="tg-yw4l">S/N</td>
                    <td class="tg-yw4l">Permissions</td>
                    <td class="tg-yw4l">Allow</td>
                </tr>
                <tr>
                    <td class="tg-yw4l">1</td>
                    <td class="tg-yw4l">Ability to view pastor forms From the backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="pastorform.view" type="checkbox" value="true"<?php echo e(!empty($permissions['pastorform.view']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">2</td>
                    <td class="tg-yw4l">Ability to Delete pastor forms From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="pastorform.delete" type="checkbox" value="true"<?php echo e(!empty($permissions['pastorform.delete']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>

                
                <tr>
                    <th class="tg-yw4l" colspan="3"><h2>Prayer Request Form Permissions</h2></th>
                </tr>
                <tr>
                    <td class="tg-yw4l">S/N</td>
                    <td class="tg-yw4l">Permissions</td>
                    <td class="tg-yw4l">Allow</td>
                </tr>
                <tr>
                    <td class="tg-yw4l">1</td>
                    <td class="tg-yw4l">Ability to view prayer request forms From the backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="prayerform.view" type="checkbox" value="true"<?php echo e(!empty($permissions['prayerform.view']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="tg-yw4l">2</td>
                    <td class="tg-yw4l">Ability to Delete prayer request forms From The Backend</td>
                    <td class="tg-yw4l">
                        <div class="field">
                            <input name="prayerform.delete" type="checkbox" value="true"<?php echo e(!empty($permissions['prayerform.delete']) ? 'checked ': ''); ?> >
                        </div>
                    </td>
                </tr>
                <tr>
                    <th class="tg-yw4l" colspan="3"> <button class="ui button" type="submit">Submit</button></th>
                </tr>
            </table>
        </div>

    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>