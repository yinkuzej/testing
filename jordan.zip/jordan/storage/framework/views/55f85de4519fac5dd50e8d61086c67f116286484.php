<?php $__env->startSection("title", "Prayer Request"); ?>
<?php $__env->startSection('og:title', "Prayer Request"); ?>
<?php $__env->startSection('og:url', 'http://www.livingpraisenanaimo.com/interactive/prayer_request'); ?>

<?php $__env->startSection('header'); ?>
    <div class="row Normal" style="margin:0 auto;">
        <img src="<?php echo e(asset('/img/rccg-logo.jpg')); ?>">
        <h2 align="center">RCCG LIVING PRAISE CHAPEL PRAYER REQUEST FORM</h2>

        <p>"Thus says the Lord who made the earth, the Lord who formed it to establish it—the Lord is his name: Call to
            me and I will answer you, and will tell you great and hidden things that you have not known."
            Jeremiah 33:2 - 3. </p>
        Complete the form below to send your prayer request. We will stand with you in prayer. Please note that fields
        highlighted in red are required

        <span>*</span>Required


        <form class="ui fluid form" role="form" action="<?php echo e(asset('/interactive/prayer-request/submit')); ?>"
              method="post">

            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="form_type" value="contact">

            <div class="field ui focus">
                <label>First Name</label>
                <input type="text" name="first_name" id="first_name" placeholder="First name">
                <div class="ui pointing label">
                    Please enter your First name
                </div>
            </div>
            <div class="ui divider"></div>
            <div class="field ui focus">
                <label>Last Name</label>
                <input type="text" name="last_name" id="last_name" placeholder="Last Name">
                <div class="ui pointing label">
                    Please enter your Last name
                </div>
            </div>
            <div class="ui divider"></div>
            <div class="field ui focus">
                <label>Phone Number</label>
                <input type="tel" name="phone" id="phone" placeholder="Phone number">
                <div class="ui pointing label">
                    Please enter your Phone number
                </div>
            </div>
            <div class="ui divider"></div>
            <div class="field ui focus">
                <label>Email Address</label>
                <input type="email" name="email" id="email" placeholder="Email Address">
                <div class="ui pointing label">
                    Please enter your Email Address
                </div>
            </div>
            <div class="ui divider"></div>
            <div class="field ui focus">
                <label>Subject</label>
                <input type="text" name="subject" id="subject" placeholder="Subject">
                <div class="ui pointing label">
                    Please enter your Subject
                </div>
            </div>
            <div class="ui divider"></div>


            <div class="column">
                <div class="ui test slider checkbox">
                    <input name="allow_contact" id="allow_contact" type="checkbox" value="yes">
                    <label>Should we contact you ? </label>
                </div>
            </div>


            <div class="ui divider"></div>
            <div class="field ui focus">
                <label>Feedback</label>
                <textarea name="feedback" id="feedback" placeholder="Feedback"></textarea>
                <div class="ui pointing label">
                    Please enter your Feedback
                </div>
            </div>

            <div class="ui large buttons">
                <button type="submit" class="ui button">Submit</button>
                <div class="or"></div>
                <button type="reset" class="ui button">Reset</button>
            </div>
        </form>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>