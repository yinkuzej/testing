<?php $__env->startSection('content'); ?>
    <script src="<?php echo e(asset('backend/vendor/tinymce/js/tinymce/tinymce.min.js')); ?>"></script>
    <script>
        tinymce.init({
            selector: 'textarea',
            height: 500,
            theme: 'modern',
            plugins: [
                'advlist autolink lists link image charmap print preview hr anchor pagebreak',
                'searchreplace wordcount visualblocks visualchars code fullscreen',
                'insertdatetime media nonbreaking save table contextmenu directionality',
                'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
            ],
            toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
            toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
            image_advtab: true,
            templates: [
                { title: 'Test template 1', content: 'Test 1' },
                { title: 'Test template 2', content: 'Test 2' }
            ],
            content_css: [
                '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                '//www.tinymce.com/css/codepen.min.css'
            ]
        });
    </script>

    <!-- Page Heading -->
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">
                Edit Blog
            </h2>
            <div class="pull-right">
                <button type="submit" class="btn btn-info" onclick="document.getElementById('myform').submit();">Submit</button>
            </div>
            <div class="pull-right">
                <button type="reset" class="btn btn-default" onclick="document.getElementById('myform').reset();">Reset</button>
            </div>
            <ol class="breadcrumb">
                <li>
                    <i class="fa fa-dashboard"></i>  <a href="<?php echo e(asset('/admin/pages')); ?>">Blogs</a>
                </li>
                <li class="active">
                    <i class="fa fa-edit"></i> Edit
                </li>
            </ol>
        </div>
    </div>
    <!-- /.row -->

    <div class="row">
        <form id="myform" role="form" action="<?php echo e(asset('admin/blogs/' . $blog->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

            <input type="hidden" name="id" value="<?php echo e($blog->id); ?>">

            <div class="col-lg-6">

                <div class="form-group">
                    <label>Blog Title</label>
                    <input class="form-control" name="title" value="<?php echo e($blog->title); ?>">
                    <p class="help-block">Will show as blog title</p>
                </div>

                <div class="form-group">
                    <label>Blog Link</label>
                    <input class="form-control" name="link" value="<?php echo e($blog->link); ?>">
                    <p class="help-block">Used as link</p>
                </div>

                <div class="form-group">
                    <label>File input</label>
                    <input type="file">
                </div>

                <div class="form-group">
                    <label>Markup</label>
                    <textarea class="form-control" name="body" rows=25"><?php echo e($blog->body); ?></textarea>
                </div>

                <button type="submit" class="btn btn-default">Submit</button>
                <button type="reset" class="btn btn-default">Reset</button>


            </div>
            <div class="col-lg-6" style="background-color: #ececec">
                <h3>Settings</h3>

                <div class="form-group">
                    <label>Display</label>
                    <select name="active" class="form-control">
                        <option value="1" <?php echo e($blog->active == '1' ? 'selected' : ''); ?>>Enable</option>
                        <option value="0" <?php echo e($blog->active == '0' ? 'selected' : ''); ?>>Disable</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Category</label>
                    <select name="category_id" class="form-control">
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($menu->id); ?>" <?php echo e($blog->category->id == $menu->id ? 'selected' : ''); ?>><?php echo e($menu->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

            </div>
        </form>
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>