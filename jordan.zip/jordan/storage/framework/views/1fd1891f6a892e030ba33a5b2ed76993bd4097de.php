<h1>Hello <?php echo e($user->first_name); ?></h1>

<p>
    Please click the following link to Reset your password.
    <a href="<?php echo e(env('APP_URL')); ?>/reset/<?php echo e($user->email); ?>/<?php echo e($code); ?>">Click Here</a>
</p>