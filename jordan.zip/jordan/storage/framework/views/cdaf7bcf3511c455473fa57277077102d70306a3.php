<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">


            <form role="form" action="/admin/testimony/<?php echo e($testimony->id); ?>" method="post">

                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <input type="hidden"  name="id"  value="<?php echo e($testimony->id); ?>" required>

                <div class="form-group">
                    <label for="name">Your Name</label>
                    <input type="text" class="form-control" name="name" id="name" placeholder="Enter Name" value="<?php echo e($testimony->name); ?>" required>
                </div>
                <div class="form-group">
                    <label for="subject">Title</label>
                    <input type="subject" class="form-control" id="subject" name="subject" placeholder="Enter Title"
                           value="<?php echo e($testimony->subject); ?>"required>
                </div>
                <div class="form-group">
                    <label for="message">Testimony</label>
                    <textarea name="message" id="message" class="form-control" rows="5" required><?php echo e($testimony->message); ?>"</textarea>
                </div>
                <div class="form-group">
                    <label for="display">Display</label>
                    <input name="display" type="checkbox" <?php echo e(($testimony->display =='Y'?'checked':'' )); ?> data-toggle="toggle" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="danger">
                </div>
                <button type="submit"class="btn btn-info pull-right">Submit</button>
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>