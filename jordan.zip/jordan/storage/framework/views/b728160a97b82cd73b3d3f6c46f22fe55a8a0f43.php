<?php $__env->startSection('content'); ?>

    <br><br><br><br><br><br><br><br>
    <form class="ui fluid form" role="form" action="/admin/workers/<?php echo e($worker->id); ?>" method="POST">

        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>


        <input type="hidden"  name="id"  value="<?php echo e($worker->id); ?>" required>

        <div class="field ui focus">
            <label>First Name</label>
            <input type="text" name="first_name" id="first_name" placeholder="First name" value="<?php echo e($worker->first_name); ?>">
        </div>
        <div class="ui divider"></div>
        <div class="field ui focus">
            <label>Last Name</label>
            <input type="text" name="last_name" id="last_name" placeholder="Last Name"  value="<?php echo e($worker->last_name); ?>">
        </div>
        <div class="ui divider"></div>
        <div class="field ui focus">
            <label>Phone Number</label>
            <input type="tel" name="phone" id="phone" placeholder="Phone number" value="<?php echo e($worker->phone); ?>">
        </div>
        <div class="ui divider"></div>
        <div class="field ui focus">
            <label>Email Address</label>
            <input type="email" name="email" id="email" placeholder="Email Address" value="<?php echo e($worker->email); ?>">
        </div>
        <div class="ui divider"></div>

        <div class="ui large buttons">
            <button type="submit" class="ui button">Submit</button>
            <div class="or"></div>
            <button type="reset" class="ui button">Reset</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>