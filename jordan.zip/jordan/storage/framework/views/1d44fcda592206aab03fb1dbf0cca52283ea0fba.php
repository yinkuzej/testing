<!-- Bootstrap core CSS -->
<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('css/flipclock.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/jquery-ui.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/fullcalendar.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/fullcalendar.print.min.css')); ?>" rel="stylesheet" media="print">
<link href="<?php echo e(asset('css/skin.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/semantic-ui/semantic.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">



<script src="<?php echo e(asset('js/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/fullcalendar.js')); ?>"></script>
<script src="<?php echo e(asset('js/flipclock.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.matchHeight.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.slides.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/skin.js')); ?>"></script>
<script src="<?php echo e(asset('assets/semantic-ui/semantic.js')); ?>"></script>
<script>

    $(function () {
        $(window).scroll(function () {

            if ($(document).scrollTop() > 150 && $(window).width() > 767) {
                $('.navbar').addClass('shrink');
            }
            else {
                $('.navbar').removeClass('shrink');
            }
        });

    });
</script>