<?php $__env->startSection('content'); ?>
    
    <script src="<?php echo e(asset('/vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>

    

    
        
            
                
                
                
                
                
                    
                    
                    
                    
                
                
                
                
                
                    
                    
                
                
                    
                    
                
            
        
    
    <div class="container">
        <div class="row">
            <h2>Add a Tract</h2>

            <form  role="form" action="<?php echo e(asset('/admin/tract/submit')); ?>" enctype="multipart/form-data" method="post" id="myform">

                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="name">Your Name</label>
                    <input type="text" class="form-control" name="name" id="name" placeholder="Enter Name" required>
                </div>
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" class="form-control" id="title" name="title" placeholder="Enter Title"
                           required>
                </div>
                <div class="form-group">
                    <label>Tract Link</label>
                    <input class="form-control" placeholder="Enter text" name="url">
                </div>

                <div class="form-group">
                    <label for="display">Display</label>
                    <input name="display" type="checkbox" checked data-toggle="toggle" data-on="Yes" data-off="No"
                           data-onstyle="success" data-offstyle="danger">
                </div>


                <div class="form-group">
                    <label for="selection">Please Choose your tract input</label>
                    <div id="tab" class="btn-group" data-toggle="buttons-radio">
                        <a href="#text" class="btn btn-large btn-info active" data-toggle="tab">Text</a>
                        <a href="#image" class="btn btn-large btn-info" data-toggle="tab">Image</a>
                    </div>
                </div>

                <div class="tab-content">
                    <div class="tab-pane active" id="text">
                        <br>
                        <div class="form-group">
                            <label for="message">Tract Text</label>
                            <textarea name="body" id="message" class="form-control" required></textarea>
                        </div>
                        <script>
                            $(function() {
                                CKEDITOR.replace( 'message', {
                                    height: 500,
//                                    extraPlugins:'dropler',
                                    extraPlugins:'imgur',
                                    imgurClientId:'5296f4abba9ae89',
                                    droplerConfig : {
                                        backend: 'imgur',
                                        settings: {
                                            clientId: '5296f4abba9ae89',
                                        },
                                    },
                                    
                                    
                                    
                                    
                                    /* Default CKEditor styles are included as well to avoid copying default styles. */
                                    contentsCss: [ 'http://cdn.ckeditor.com/4.6.2/full-all/contents.css', 'http://sdk.ckeditor.com/samples/assets/css/classic.css' ]
                                } );
                                CKEDITOR.editorConfig = function( config ) {
                                    config.uiColor = '#F7B42C';
                                    config.height = 500;
                                    config.toolbarCanCollapse = true;
                                    // rest of config
                                    config.extraPlugins = 'dropler';

                                    // configure the backend service and credentials
                                    config.droplerConfig = {
                                        backend: 'imgur',
                                        settings: {
                                            clientId: '5296f4abba9ae89'
                                        }
                                    }

                                };



                            });
                        </script>
                    </div>
                    <div class="tab-pane" id="image">
                        <br>
                        <br>
                        <div class="form-group">
                            <label for="message">Tract images</label>
                            <div class="container">
                                <?php echo $__env->make('tools.image-upload', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ui large buttons">
                    <button type="submit" onclick="document.getElementById('myform').submit();" class="ui button">Submit</button>
                    <div class="or"></div>
                    <button type="reset" class="ui button">Reset</button>
                </div>
            </form>


        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>