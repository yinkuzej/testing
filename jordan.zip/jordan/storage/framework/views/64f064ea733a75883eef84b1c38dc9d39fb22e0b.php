<footer class="footer">
    <div class="container footer-top siteFooter">
        <div class="col-md-4">
            <h2>ABOUT US</h2>
            <p>Living Praise Chapel is a part of the global Redeemed Christian Church
                of God. RCCG Living Praise Chapel is a family oriented multicultural community
                of believers. Our aim is to spread the Gospel of our Lord Jesus Christ
                towards the restoration of souls with the goal of eternal salvation.</p>
            <a class="s" href="/about-us/who-we-are">
                <img alt="" src="<?php echo e(asset('learnmore.png')); ?>" style="width: 175px; height: 51px;">
            </a>
        </div>
        <div class="col-md-4">
            <h2>SERVICES</h2>
            <p>
                <b>Worship service on Sundays</b>
                <br>Family Worship:10:00AM - 12:15NOON
                <br>
                <br>
                <b>TUESDAY - THURSDAY</b>
                <br>Free Counselling &amp; Prayer: 10:00AM - 4:00PM
                <br>
                <br>
                <b>WEDNESDAY</b>
                <br>Bible Study: 7:00PM – 8:00PM
                <br>
                <br>
                <b>FRIDAYS</b>
                <br>&nbsp;Open House Prayer: 7:00PM – 8:00PM
                <br>
                <br>[
                <a class="f1" href="services.html">View all services</a>]</p>
        </div>
        <div class="col-md-4">
            <h2>WORSHIP CENTER</h2>
            <b>LIVING PRAISE CHAPEL</b>
            <br>216 Prideaux St.&nbsp;
            <br>Nanaimo,&nbsp;BC&nbsp;
            <br>V9R 2N1
            <br>[
            <a class="f1"
               href="https://www.google.ca/maps/dir//216+Prideaux+St,+Nanaimo,+BC+V9R+2N1/@49.1661423,-123.9465828,17z/data=!4m13!1m4!3m3!1s0x5488a3e233839e61:0xca5dc4826cffd2ae!2s216+Prideaux+St,+Nanaimo,+BC+V9R+2N1!3b1!4m7!1m0!1m5!1m1!1s0x5488a3e233839e61:0xca5dc4826cffd2ae!2m2!1d-123.9443941!2d49.1661388">get
                directions</a>]
            <br>
            <br>
            <br>
            <b>Church Office Hours:</b>
            <br>Tuesday – Thursday 10:00AM – 4:00PM
            <br>Phone:
            <a class="f1" href="tel: +12507559202">+12507559202</a>
            <br>Email:
            <a class="f1" href="mailto: rccglivingpraisechapel@yahoo.ca?Subject=Church%20Inquiry" target="_top">rccglivingpraisechapel@yahoo
                .ca</a>
        </div>
    </div>

    <!--footer navbar -->
    <div class="container footer-middle">
        <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
            <h3> Lorem Ipsum </h3>
            <ul>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
            </ul>
        </div>
        <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
            <h3> Lorem Ipsum </h3>
            <ul>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
            </ul>
        </div>
        <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
            <h3> Lorem Ipsum </h3>
            <ul>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
            </ul>
        </div>
        <div class="col-lg-2  col-md-2 col-sm-4 col-xs-6">
            <h3> Lorem Ipsum </h3>
            <ul>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
                <li><a href="#"> Lorem Ipsum </a></li>
            </ul>
        </div>
        <div class="col-lg-3  col-md-3 col-sm-6 col-xs-12 ">
            <h3> Lorem Ipsum </h3>
            <ul>
                <li>
                    <div class="input-append newsletter-box text-center">
                        <input type="text" class="full text-center" placeholder="Email ">
                        <button class="btn  bg-gray" type="button"> Lorem ipsum <i class="fa fa-long-arrow-right"> </i>
                        </button>
                    </div>
                </li>
            </ul>
            <ul class="social">
                <li><a href="#"> <i class=" fa fa-facebook">   </i> </a></li>
                <li><a href="#"> <i class="fa fa-twitter">   </i> </a></li>
                <li><a href="#"> <i class="fa fa-google-plus">   </i> </a></li>
                <li><a href="#"> <i class="fa fa-pinterest">   </i> </a></li>
                <li><a href="#"> <i class="fa fa-youtube">   </i> </a></li>
            </ul>
        </div>
    </div>
    <!--/.row-->
    <div class="container footer-bottom">
        <div class="container">
            <p class="pull-left"> Copyright © NCCG 2016. All right reserved. </p>
            <div class="pull-right">
                <ul class="nav nav-pills payments">
                    <li><i class="fa fa-cc-visa"></i></li>
                    <li><i class="fa fa-cc-mastercard"></i></li>
                    <li><i class="fa fa-cc-amex"></i></li>
                    <li><i class="fa fa-cc-paypal"></i></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->