<header id="home" class="home">
    <div class="overlay-img">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <div class="home-content">

                        <h5>capture the moment</h5>
                        <h1>Snap<span>Perfection</span></h1>

                        <a target="_blank" href="#"><button class="btn btn-default btn-home">BOOK NOW!<span></span></button></a>

                    </div>
                </div>
            </div>

        </div>
    </div>
</header>