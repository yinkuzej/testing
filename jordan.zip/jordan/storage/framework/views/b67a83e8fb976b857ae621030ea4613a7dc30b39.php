<style>



    #calendar {
        max-width: 900px;
        margin: 0 auto;
        margin: 40px 10px;
        padding: 0;
        font-family: "Lucida Grande", Helvetica, Arial, Verdana, sans-serif;
        font-size: 14px;
    }

</style>
<?php if(showEvent()): ?>
    <script type="text/javascript">
        var clock;

        $(document).ready(function () {
            var clock;
            // Grab the current date
            var currentDate = new Date();
            var futureDate = new Date(<?php echo e(getEventSettings()->next_event_time); ?>);
            // Calculate the difference in seconds between the future and current date
            var diff = (futureDate.getTime() / 1000 - currentDate.getTime() / 1000) - 30;
            // Instantiate a coutdown FlipClock
            clock = $('.clock').FlipClock(diff, {
                clockFace: 'DailyCounter',
                countdown: true,
                showSeconds: true
            });
        });
    </script>
    <script type="text/javascript">
        $(document).ready(function () {
            if (screen.width <= 411) {
                $("#count2").hide();
            }
            else {
                $("#count2").show();
            }
        });
    </script>
<?php endif; ?>