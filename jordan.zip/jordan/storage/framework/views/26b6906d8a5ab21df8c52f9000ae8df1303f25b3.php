<nav class="navbar navbar-fixed-top normal" role="navigation">

    <div class="container wide">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                    aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/"><img class="img-responsive" src="<?php echo e(asset('logo.png')); ?>" alt="Logo"></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">

            <ul class="nav navbar-nav">
                <li class="">
                    <a href="/">Home</a>
                </li>
                <li class="dropdown">
                    <a href="about_us.html" class="dropdown-toggle" data-toggle="dropdown" role="button"
                       aria-expanded="false">About Us <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li>
                            <a href="/about-us/who-we-are">Who We Are</a>
                        </li>
                        <li>
                            <a href="/about-us/rccg">RCCG</a>
                        </li>
                        <li>
                            <a href="/about-us/vision">Vision</a>
                        </li>
                        <li>
                            <a href="/about-us/belief">Our Beliefs</a>
                        </li>
                        <li>
                            <a href="/about-us/pastor">Pastor's Welcome Message</a>
                        </li>
                        <li>
                            <a href="/about-us/services">Service Times</a>
                        </li>
                        <li>
                            <a href="/about-us/contact">Contact Us</a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Resources
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li>
                            <a href="/resources/upcoming-events">Upcoming Events</a>
                        </li>
                        <li>
                            <a href="/resources/birthdays">Birthdays</a>
                        </li>
                        <li>
                            <a href="/resources/bulletins">Bulletin Archives</a>
                        </li>
                        <li>
                            <a href="/resources/special_prayers">Special Prayers</a>
                        </li>
                        <li>
                            <a href="/resources/flyers">Flyers</a>
                        </li>
                        <li>
                            <a href="/resources/testimony">Testimony</a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Interactive
                        <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li>
                            <a href="/interactive/prayer-request/">Prayer Request</a>
                        </li>
                        <li>
                            <a href="/interactive/blogs">Blog</a>
                        </li>
                        <li>
                            <a href="/interactive/tracts">Tracts</a>
                        </li>
                        <li>
                            <a href="/interactive/testimonies/submit">Submit a Testimony</a>
                        </li>
                        <li>
                            <a href="/interactive/faq">FAQ</a>
                        </li>
                        
                            
                        
                        
                            
                        
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Media
                        Center <span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li>
                            <a href="/media_center/videos">Video Library</a>
                        </li>
                        <li>
                            <a href="/media_center/gallery">Photo Gallery</a>
                        </li>
                    </ul>
                </li>
                <?php if(showEvent()): ?>
                    <li class="dropdown count1" id="count2">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Next
                            Event </a>
                        <ul class="dropdown-menu count" role="menu">
                            <h3 align="center" style="color: black;"><?php echo e(getEventSettings()->next_event_text); ?> Begins in </h3>
                            <div class="clock" style="margin:2em;"></div>
                            <div class="message"></div>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php if(\Cartalyst\Sentinel\Laravel\Facades\Sentinel::check()): ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><span class="glyphicon glyphicon-user" aria-hidden="true"></span><?php echo e(Sentinel::getUser()->first_name); ?>

                            <span class="caret"></span></a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="<?php echo e(url('/dashboard')); ?>"> Dashboard</a>
                            </li>
                        </ul>

                    </li>
                    <li>
                        <a href="<?php echo e(url('/logout')); ?>"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <span class="glyphicon glyphicon-log-out" aria-hidden="true"></span> Logout
                        </a>

                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                <?php else: ?>

                    <li><a href="<?php echo e(url('/register')); ?>"><span class="glyphicon glyphicon-user"
                                                               aria-hidden="true"></span> Register</a>
                    </li>
                    <li><a href="<?php echo e(url('/login')); ?>"><span class="glyphicon glyphicon-log-in"
                                                            aria-hidden="true"></span> Login</a>
                    </li>


                <?php endif; ?>
            </ul>
        </div>
        <!--/.nav-collapse -->
    </div>
    <!--/.contatiner -->
</nav>
