<?php $__env->startSection('content'); ?>
    <script src="<?php echo e(asset('backend/vendor/tinymce/js/tinymce/tinymce.min.js')); ?>"></script>
    <script>
        tinymce.init({
            selector: 'textarea',
            height: 500,
            theme: 'modern',
            plugins: [
                'advlist autolink lists link image charmap print preview hr anchor pagebreak',
                'searchreplace wordcount visualblocks visualchars code fullscreen',
                'insertdatetime media nonbreaking save table contextmenu directionality',
                'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
            ],
            toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
            toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
            image_advtab: true,
            templates: [
                { title: 'Test template 1', content: 'Test 1' },
                { title: 'Test template 2', content: 'Test 2' }
            ],
            content_css: [
                '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                '//www.tinymce.com/css/codepen.min.css'
            ]
        });
    </script>
    <div class="page-header">
        <h1>Pastor's Settings</h1>
    </div>
    <div class="row">
        <form id="myform" role="form" action="<?php echo e(asset('admin/pastor/settings')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

            <input type="hidden" name="id" value="<?php echo e($settings->id); ?>">

            <div class="col-lg-6">

                <div class="form-group">
                    <label>Welcome Message</label>
                    <textarea class="form-control" name="welcome_message" rows=25"><?php echo e($settings->welcome_message); ?></textarea>
                    <p class="help-block">Will show as blog title</p>
                </div>

                <div class="form-group">
                    <label>File input/ Image for Welcome Address </label>
                    <input name="welcome_message_image" type="file">
                </div>

                <div class="form-group">
                    <label>Quote of The Day</label>
                    <textarea class="form-control" name="quote_of_the_day" rows=25"><?php echo e($settings->quote_of_the_day); ?></textarea>
                    <p class="help-block">Used as link</p>
                </div>


                <div class="form-group">
                    <label>Message Of THe Day</label>
                    <textarea class="form-control" name="message_of_the_day" rows=25"><?php echo e($settings->message_of_the_day); ?></textarea>
                </div>

                 <button type="submit" class="ui button">Update</button>


            </div>

        </form>
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>