<?php $__env->startSection("title", "Who We Are"); ?>
<?php $__env->startSection('og:title', "Who We Are"); ?>
<?php $__env->startSection('og:url', 'http://www.livingpraisenanaimo.com/about-us/who-we-are'); ?>

    <?php $__env->startSection('header'); ?>


<h1>Who We Are</h1>
<p>
    Living Praise Chapel is a part of the global Redeemed Christian Church
    of God. RCCG Living Praise Chapel is a family oriented multicultural community
    of believers.
</p>
<p> Our aim is to spread the Gospel of our Lord Jesus Christ
    towards the restoration of souls with the goal of eternal salvation.
</p>
<p>In
    doing so, our standard book of reference is the Holy Bible, while righteousness
    and holiness remain our core values. In the cause of our activities and
    in order to impact our society and humanity positively, we shall also be
    involved in humanitarian and philanthropic activities.
</p>
<p> Having done all, we will remain standing, waiting and watching for the return of our Lord
    Jesus Christ and the glorious Marriage Supper of the Lamb. Amen.
</p>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('../../layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>