<?php $__env->startSection('content'); ?>

    <!-- blog Heading -->
    <br><br><br><br><br><br><br><br>

    <div class="ui fluid input icon">
        <div class="ui icon input">
            <input class="prompt" id="search-input" type="text" placeholder="Search Blogs">
            <i class="search icon"></i>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <?php if(!empty($keywords)): ?>
                <h2 class="blog-keywords">Blogs that contain "<em><?php echo e($keywords); ?></em>"</h2>
            <?php else: ?>
                <h2 class="blog-keywords">All Blogs</h2>
            <?php endif; ?>

            <div>
                <a href="<?php echo e(asset('/admin/blogs/create')); ?>" class="btn btn-primary btn-sx"><i class="fa fa-edit"></i> CREATE</a>
            </div>
            <div class="blog-nav">
            <?php echo $blogs->links(); ?>


            </div>
            <div class="table-responsive">
                <table class="table table-hover table-striped">
                    <thead class="thead-inverse">
                    <tr>
                        <th>blog Name</th>
                        <th>Link</th>
                        <th>Category</th>
                        <th>Active</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th colspan="2">Action</th>
                    </tr>
                    </thead>
                    <tbody id="results">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="active">
                            <td><a href="<?php echo e(asset('/admin/blog\/') . $blog->id); ?>"><?php echo e($blog->title); ?></a></td>
                            <td><?php echo e($blog->link); ?></td>
                            <td><?php echo e($blog->category->name); ?></td>
                            <td><?php echo e($blog->active ? 'Enabled' : 'Disabled'); ?></td>
                            <td><?php echo e($blog->created_at->format('M d,Y \a\t h:i a')); ?></td>
                            <td><?php echo e($blog->updated_at->format('M d,Y \a\t h:i a')); ?></td>
                            <td><a href="<?php echo e(asset('/admin/blogs/' . $blog->id . '/edit')); ?>" class="btn btn-info btn-xs">EDIT</a></td>
                            <td>
                                <form action="<?php echo e(asset('/admin/blogs/' . $blog->id)); ?>" method="POST">
                                    <?php echo e(method_field('DELETE')); ?>

                                    <?php echo e(csrf_field()); ?>

                                    <input type="submit" class="btn btn-danger btn-xs" value="DELETE">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- /.row -->
    <div class="blog-nav">
        <?php echo $blogs->links(); ?>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>