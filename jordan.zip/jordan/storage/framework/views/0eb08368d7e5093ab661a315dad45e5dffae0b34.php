<?php $__env->startSection('content'); ?>
<br><br><br><br><br><br><br><br>

<div class="ui fluid input icon">
    <div class="ui icon input">
        <input class="prompt" id="prayer-search-input" type="text" value="<?php echo e((!empty($keywords)? $keywords :'')); ?>" placeholder="Search Request By User">
        <i class="search icon"></i>
    </div>
</div>
    <div class="page-header">
        <?php if(!empty($keywords)): ?>
            <h2 class="prayer-keywords">Prayer requests by "<em><?php echo e($keywords); ?></em>"</h2>
        <?php else: ?>
            <h2 class="prayer-keywords">All Prayer Request</h2>
        <?php endif; ?>
    </div>


    <div class="row">
        <div class="col-md-12">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Can Be contacted</th>
                    <th>Question</th>
                    <th class="text-right">OPTIONS</th>
                </tr>
                </thead>

                <tbody id="results">

                <?php $__currentLoopData = $contact_forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact_form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($contact_form->first_name); ?> <?php echo e($contact_form->last_name); ?></td>
                        <td><?php echo e(ucfirst($contact_form->allow_contact)); ?></td>
                        <td><?php echo e($contact_form->feedback); ?></td>

                        <td class="text-right">
                            <a class="btn btn-primary" href="<?php echo e(asset('/admin/prayer-form/'.$contact_form->id)); ?>">View</a>
                            <form action="/admin/prayer-form/<?php echo e($contact_form->id); ?>/delete" method="DELETE" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><button class="btn btn-danger" type="submit">Delete</button></form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

        </div>
    </div>
<div class="prayer-nav">
    <?php echo e($contact_forms->links()); ?>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>