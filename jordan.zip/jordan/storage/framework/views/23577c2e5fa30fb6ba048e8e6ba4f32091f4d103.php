<?php if(!empty($searchBlogs)): ?>
    <?php if($phrase == 'blogs'): ?>
        <h3>More results found <a href="/admin/blogs/search/<?php echo e($keywords); ?>">View More Results Like <?php echo e($keywords); ?></a></h3>
    <?php elseif($phrase == 'testimonies'): ?>
        <h3>More results found <a href="/admin/testimonies/search/<?php echo e($keywords); ?>">View More Results Like <?php echo e($keywords); ?></a></h3>
    <?php elseif($phrase == 'contact'): ?>
        <h3>More results found <a href="/admin/forms/contact/search/<?php echo e($keywords); ?>">View More Results Like <?php echo e($keywords); ?></a></h3>
    <?php elseif($phrase == 'prayer'): ?>
        <h3>More results found <a href="/admin/forms/prayer/search/<?php echo e($keywords); ?>">View More Results Like <?php echo e($keywords); ?></a></h3>
    <?php elseif($phrase == 'tracts'): ?>
        <h3>More results found <a href="/admin/tracts/search/<?php echo e($keywords); ?>">View More Results Like <?php echo e($keywords); ?></a></h3>
    <?php elseif($phrase == 'workers'): ?>
        <h3>More results found <a href="/admin/workers/search/<?php echo e($keywords); ?>">View More Results Like <?php echo e($keywords); ?></a></h3>
    <?php elseif($phrase == 'users'): ?>
        <h3>More results found <a href="/admin/users/search/<?php echo e($keywords); ?>">View More Results Like <?php echo e($keywords); ?></a></h3>

    <?php endif; ?>
<?php endif; ?>