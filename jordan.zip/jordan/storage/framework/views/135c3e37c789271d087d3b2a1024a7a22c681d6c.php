
<div id="overlay">
    <a href="#" class="close">&times;</a>
    <div style="height:20%"></div>

    <h2 style="font-size:35px">Pure CSS Overlay</h2>
    <br />
    <br />
    <br />
    <p style="font-size:22px;" id="overlay-content"><?php echo $__env->yieldContent('overlay-content'); ?></p>

</div>
<div id="mask" onclick="document.location='#';"></div>
<style>
    *{margin:0;padding:0;}
    #overlay{ /* we set all of the properties for are overlay */
        height:80%;
        width:80%;
        margin:0 auto;
        background:white;
        color:black;
        padding:10px;
        position:absolute;
        left: 10%;
        margin-top:20%;
        z-index:1000;
        display:none;
        /* CSS 3 */
        -webkit-border-radius:10px;
        -moz-border-radius:10px;
        -o-border-radius:10px;
        border-radius:10px;
    }

    #mask{ /* create are mask */
        position:fixed;
        top:25px;
        left:0;
        background:rgba(0,0,0,0.6);
        z-index:500;
        width:100%;
        height:100%;
        display:none;
    }
    /* use :target to look for a link to the overlay then we find are mask */
    #overlay:target, #overlay:target + #mask{
        display:block;
        opacity:1;
    }
    .close{ /* to make a nice looking pure CSS3 close button */
        display:block;
        position:absolute;
        top:-20px;
        right:-20px;
        background:deepskyblue;
        color:white;
        height:20px;
        width:20px;
        line-height:40px;
        font-size:35px;
        text-decoration:none;
        text-align:center;
        font-weight:bold;
        -webkit-border-radius:40px;
        -moz-border-radius:40px;
        -o-border-radius:40px;
        border-radius:40px;
    }
    #open-overlay{ /* open the overlay */
        display:inline-block;
    }
</style>