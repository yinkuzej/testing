<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">


            <form role="form" action="/admin/slideshow/<?php echo e($slideshow->id); ?>" method="post">

                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <input type="hidden"  name="id"  value="<?php echo e($slideshow->id); ?>" required>

                <div class="form-group">
                    <label for="name">Your Title</label>
                    <input type="text" class="form-control" name="title" id="name" placeholder="Enter Name" value="<?php echo e($slideshow->title); ?>" required>
                </div>
                <div class="form-group">
                    <label for="subject">Title</label>
                    <input type="subject" class="form-control" id="subject" name="subject" placeholder="Enter Title"
                           value="<?php echo e($slideshow->link); ?>"required>
                    <form action="/admin/slideshow/<?php echo e($slideshow->id); ?>/delete" method="DELETE" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><button class="btn btn-danger" type="submit">Delete</button></form>
                </div>
                <div class="form-group">
                    <label for="subject">Image</label>
                    <img src="<?php echo e($slideshow->image); ?>" style="width: 100px; height: 100px;">

                </div>
                <div class="form-group">
                    <label for="display">Display</label>
                    <input name="display" type="checkbox" <?php echo e(($slideshow->display =='yes'?'checked':'' )); ?> data-toggle="toggle" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="danger">
                </div>
                <button type="submit"class="btn btn-info pull-right">Submit</button>
            </form>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>