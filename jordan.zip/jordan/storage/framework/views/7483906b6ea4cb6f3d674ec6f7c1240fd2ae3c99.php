<?php $__env->startSection('header'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <strong>Success!</strong> <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-error">
            <strong>oops!</strong> <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <?php $__currentLoopData = $testimonies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimony): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <blockquote class="blockquote">
            <p class="mb-0"><?php echo e($testimony->message); ?></p>
            <footer class="blockquote-footer"> By <?php echo e($testimony->name); ?> at <cite
                        title="Source Title"><?php echo e($testimony->published_at); ?></cite></footer>
        </blockquote>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($testimonies->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>