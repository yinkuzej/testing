<?php $__env->startSection('header'); ?>
    <div class="main container">
              <!-- Main Blog Content -->
        <?php
        $_SERVER['SERVER_NAME'] = 'http://'.$_SERVER['SERVER_NAME'];
        foreach ($blogs as $blog){
        $categories = $blog->category;
        ?>
        <article>
            <h2 class="ui header"><a href="#"><?php echo e($blog->title); ?></a>
                <div class=" sub header">
                    Written by <a href="#"><?php echo e($blog->getAuthorName()); ?></a> on <?php echo e($blog->created_at->Format('F j, Y, g:i A')); ?>.

                    <span class="ui right floated medium labels">
                        
                <div class="ui label">
                    <i class="tag icon"></i> <a href="<?php echo e($categories->id); ?>"><?php echo e($categories->name); ?></a>
                </div>
                        
                    </span>
                    <p><?php echo e($blog->views); ?> Views, <?php echo e($blog->getCommentsCount()); ?> Comments.</p>
                </div>
            </h2>

            <img class="ui right floated image" src="http://placehold.it/400x240&amp;text=[img]">
            <?php echo truncate($blog->body,'/interactive/blogs/blog/'.$blog->link,600); ?>

            <div style="clear: both;"></div>
        </article>

        <div class="socials computer">
            <a class="ui facebook button" href="javascript:var w = window.open('http://www.facebook.com/sharer.php?u=<?= rawurlencode(sprintf($_SERVER['SERVER_NAME'].'/interactive/blogs', $blog['link'])); ?>&amp;t=<?=str_replace("%27","",urlencode($blog['title'])); ?>', 'sharer', 'toolbar=0,status=0,scrollbars=1,width=660,height=400'); w.focus();" title="Share on Facebook"> <i class="facebook icon"></i>Facebook</a>
            <a class="ui twitter button" href="javascript:var w = window.open('http://twitter.com/home?status=<?= rawurlencode('Check out this blog post: ' . sprintf($_SERVER['SERVER_NAME'].'/interactive/blogs/blog'.$blog['link'], $blog['link']));?>', 'twittersharer', 'toolbar=0,status=0,scrollbars=1,width=400,height=325'); w.focus();" title="Share on Twitter"> <i class="twitter icon"></i>Twitter</a>
            <a class="ui google plus button" href="javascript:var w = window.open('https://plusone.google.com/share?url=<?= rawurlencode(sprintf($_SERVER['SERVER_NAME'].'/interactive/blogs', $blog['link'])); ?>', 'gplusshare', 'toolbar=0,status=0,scrollbars=1,width=600,height=450'); w.focus();" title="Share on Google+"> <i class="google plus icon"></i>Google +</a>
            <a class="ui mail button" href="mailto:?subject=<?=rawurlencode($blog['title']);?>&body=<?= rawurlencode("I was looking at " . $_SERVER['SERVER_NAME'] . "/interactive/blogs and I thought you would like to look at this blog entry:\r\n" . sprintf($_SERVER['SERVER_NAME'].'/interactive/blogs/blog/'.$blog['link'], $blog['link']));?>" title="Send to a friend"> <i class="mail icon"></i>Email</a>
        </div>


        
        <div class="socials mobile">
            <a class="ui circular facebook icon button" href="javascript:var w = window.open('http://www.facebook.com/sharer.php?u=<?= rawurlencode(sprintf($_SERVER['SERVER_NAME'].'/interactive/blogs', $blog['link'])); ?>&amp;t=<?=str_replace("%27","",urlencode($blog['title'])); ?>', 'sharer', 'toolbar=0,status=0,scrollbars=1,width=660,height=400'); w.focus();"  title="Share on Facebook"> <i class="facebook icon"></i></a>
            <a class="ui circular twitter icon button" href="javascript:var w = window.open('http://twitter.com/home?status=<?= rawurlencode('Check out this blog post: ' . sprintf($_SERVER['SERVER_NAME'].'/interactive/blogs/blog'.$blog['link'], $blog['link']));?>', 'twittersharer', 'toolbar=0,status=0,scrollbars=1,width=400,height=325'); w.focus();" title="Share on Twitter"> <i class="twitter icon"></i></a>
            <a class="ui circular google plus icon button" href="javascript:var w = window.open('https://plusone.google.com/share?url=<?= rawurlencode(sprintf($_SERVER['SERVER_NAME'].'/interactive/blogs', $blog['link'])); ?>', 'gplusshare', 'toolbar=0,status=0,scrollbars=1,width=600,height=450'); w.focus();" title="Share on Google+"> <i class="google plus icon"></i></a>
            <a class="ui circular mail button" href="mailto:?subject=<?=rawurlencode($blog['title']);?>&body=<?= rawurlencode("I was looking at " . $_SERVER['SERVER_NAME'] . "/interactive/blogs and I thought you would like to look at this blog entry:\r\n" . sprintf($_SERVER['SERVER_NAME'].'/interactive/blogs/blog/'.$blog['link'], $blog['link']));?>" title="Send to a friend"> <i class="mail icon"></i></a>
        </div>

        <style>
            @media(min-width: 1000px){
                .socials.computer {
                    display:block;
                }
                .socials.mobile {
                    display:none;
                }
            }
            @media(max-width: 999px){
                .socials.computer {
                    display:none;
                }
                .socials.mobile {
                    display:block;
                }
            }
        </style>


        <div class="ui divider" style="clear: both;"></div>
        <?php } ?>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('../../layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>