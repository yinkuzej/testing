<h1>Hello <?php echo e($user->first_name); ?></h1>

<p>
    Please click the following link to activate your account.
    <a href="<?php echo e(env('APP_URL')); ?>/activate/<?php echo e($user->email); ?>/<?php echo e($code); ?>">Activate Account</a>
</p>