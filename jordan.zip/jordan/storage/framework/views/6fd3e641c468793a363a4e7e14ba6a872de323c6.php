<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta property="og:site_name" content="RCCG Living Praise Chapel Nanaimo"/>
    <meta property="og:description" content="RCCG Living Praise Chapel Nanaimo"/>
    <meta property="og:title" content="<?php echo $__env->yieldContent('og:title'); ?>"/>
    <meta property="og:url" content="<?php echo $__env->yieldContent('og:url'); ?>"/>

    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <?php echo $__env->make('layouts.partials.mixed', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <style type="text/css">
        body {
            background-color: #DADADA;
        }
        body > .grid {
            height: 100%;
        }
        .image {
            margin-top: -100px;
        }
        .column {
            max-width: 450px;
        }
    </style>
</head>
<body>
        <?php echo $__env->yieldContent('header'); ?>
</body>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>


</html>