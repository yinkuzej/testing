        <?php $__currentLoopData = $searchBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($phrase == 'blogs'): ?>
            <tr class="active">
                <td><a href="<?php echo e(asset('/admin/blog\/') . $blog->id); ?>"><?php echo e($blog->title); ?></a></td>
                <td><?php echo e($blog->link); ?></td>
                <td><?php echo e($blog->category->name); ?></td>
                <td><?php echo e($blog->active ? 'Enabled' : 'Disabled'); ?></td>
                <td><?php echo e($blog->created_at->format('M d,Y \a\t h:i a')); ?></td>
                <td><?php echo e($blog->updated_at->format('M d,Y \a\t h:i a')); ?></td>
                <td><a href="<?php echo e(asset('/admin/blogs/' . $blog->id . '/edit')); ?>" class="btn btn-info btn-xs">EDIT</a></td>
                <td>
                    <form action="<?php echo e(asset('/admin/blogs/' . $blog->id)); ?>" method="POST">
                        <?php echo e(method_field('DELETE')); ?>

                        <?php echo e(csrf_field()); ?>

                        <input type="submit" class="btn btn-danger btn-xs" value="DELETE">
                    </form>
                </td>
            </tr>

            <?php elseif($phrase == 'testimonies'): ?>

                  <tr  class="active">
                    <td><?php echo e($blog->name); ?></td>
                    <td><?php echo e($blog->subject); ?></td>
                    <td><?php echo e($blog->message); ?></td>

                    <td class="text-right">
                        <input type="checkbox" <?php echo e(($blog->display =='Y'?'checked':'' )); ?> data-toggle="toggle" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="danger">
                        <a class="btn btn-primary" href="<?php echo e(asset('/admin/testimony/'.$blog->id)); ?>">View</a>
                        <a class="btn btn-warning " href="<?php echo e(asset('/admin/testimony/'.$blog->id.'/edit')); ?>">Edit</a>
                        <form action="/admin/testimony/<?php echo e($blog->id); ?>/delete" method="DELETE" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><button class="btn btn-danger" type="submit">Delete</button></form>
                    </td>
                </tr>

            <?php elseif($phrase == 'contact'): ?>
                <tr>
                    <td><?php echo e($blog->first_name); ?> <?php echo e($blog->last_name); ?></td>
                    <td><?php echo e($blog->subject); ?></td>
                    <td><?php echo e($blog->feedback); ?></td>

                    <td class="text-right">
                        <input type="checkbox" <?php echo e(($blog->display =='Y'?'checked':'' )); ?> data-toggle="toggle" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="danger">
                        <a class="btn btn-primary" href="<?php echo e(asset('/admin/contact-form/'.$blog->id)); ?>">View</a>
                        <form action="/admin/contact-form/<?php echo e($blog->id); ?>/delete" method="DELETE" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><button class="btn btn-danger" type="submit">Delete</button></form>
                    </td>
                </tr>
                
            <?php elseif($phrase == 'prayer'): ?>
                <tr>
                    <td><?php echo e($blog->first_name); ?> <?php echo e($blog->last_name); ?></td>
                    <td><?php echo e(ucfirst($blog->allow_contact)); ?></td>
                    <td><?php echo e($blog->feedback); ?></td>

                    <td class="text-right">
                        <a class="btn btn-primary" href="<?php echo e(asset('/admin/prayer-form/'.$blog->id)); ?>">View</a>
                        <form action="/admin/prayer-form/<?php echo e($blog->id); ?>/delete" method="DELETE" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><button class="btn btn-danger" type="submit">Delete</button></form>
                    </td>
                </tr>

            <?php elseif($phrase == 'tracts'): ?>
                <tr>
                    <td><?php echo e($blog->title); ?></td>

                    <td class="text-right">
                        <input type="checkbox" <?php echo e(($blog->display =='Y'?'checked':'' )); ?> data-toggle="toggle" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="danger">
                        <a class="btn btn-primary" href="<?php echo e(asset('/admin/tract/'.$blog->id)); ?>">View</a>
                        <a class="btn btn-warning " href="<?php echo e(asset('/admin/tract/'.$blog->id.'/edit')); ?>">Edit</a>
                        <form action="/admin/tract/<?php echo e($blog->id); ?>/delete" method="DELETE" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><button class="btn btn-danger" type="submit">Delete</button></form>
                    </td>
                </tr>

            <?php elseif($phrase == 'workers'): ?>
                <tr>
                    <td><?php echo e(ucfirst(strtolower($blog->first_name)) .' '. ucfirst(strtolower($blog->last_name))); ?></td>
                    <td><?php echo e($blog->email); ?></td>
                    
                    
                    
                    

                    <td class="text-right">
                        <a class="btn btn-primary" href="<?php echo e(route('workers.show', $blog->id)); ?>">View</a>
                        <a class="btn btn-warning " href="<?php echo e(route('workers.edit', $blog->id)); ?>">Edit</a>
                        <a class="btn btn-warning " href="/admin/workers/<?php echo e($blog->id); ?>/permissions">Change Permissions</a>
                        <form action="<?php echo e(route('workers.destroy', $blog->id)); ?>" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><input type="hidden" name="_method" value="DELETE"><input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <button class="btn btn-danger" type="submit">Delete</button></form>
                    </td>
                </tr>

         <?php elseif($phrase == 'users'): ?>
                <tr>
                    <td><?php echo e(ucfirst(strtolower($blog->first_name)) .' '. ucfirst(strtolower($blog->last_name))); ?></td>
                    <td><?php echo e($blog->email); ?></td>
                    
                    
                    
                    

                    <td class="text-right">
                        <a class="btn btn-primary" href="<?php echo e(route('users.show', $blog->id)); ?>">View</a>
                        <a class="btn btn-warning " href="<?php echo e(route('users.edit', $blog->id)); ?>">Edit</a>
                        <a class="btn btn-warning " href="/admin/users/<?php echo e($blog->id); ?>/permissions">Change Permissions</a>
                        <form action="<?php echo e(route('users.destroy', $blog->id)); ?>" method="POST" style="display: inline;" onsubmit="if(confirm('Delete? Are you sure?')) { return true } else {return false };"><input type="hidden" name="_method" value="DELETE"><input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <button class="btn btn-danger" type="submit">Delete</button></form>
                    </td>
                </tr>

            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



