<?php $__env->startSection('header'); ?>
<?php $__env->startSection("title", "Upcoming Events"); ?>
<?php $__env->startSection('og:title', "Upcoming Events"); ?>
<?php $__env->startSection('og:url', 'http://www.livingpraisenanaimo.com/resources/upcoming_events'); ?>

<?php $__env->startSection('content'); ?>
<div style="width: 800px;">
    <?php echo $calendar->calendar(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $calendar->script(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>