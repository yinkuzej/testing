<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta property="og:site_name" content="RCCG Living Praise Chapel Nanaimo"/>
    <meta property="og:description" content="RCCG Living Praise Chapel Nanaimo"/>
    <meta property="og:title" content="<?php echo $__env->yieldContent('og:title'); ?>"/>
    <meta property="og:url" content="<?php echo $__env->yieldContent('og:url'); ?>"/>

    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>">

   <?php echo $__env->make('layouts.partials.mixed', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.partials.events', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<?php echo $__env->make('layouts.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container" style="margin-top: 120px; margin-bottom: 120px;">
    <?php echo $__env->make('tools.overlay', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row Normal">
        <?php echo $__env->yieldContent('header'); ?>
    </div>
</div>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>


</html>