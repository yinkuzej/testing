<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
//
Auth::routes();

Route::get('/', 'HomeController@index');
Route::post('/form/contact/submit', 'HomeController@submitContactForm');

Route::get('/profile', 'ProfileController@index');

Route::get('/register', 'Auth\RegistrationController@register');
Route::post('/register', 'Auth\RegistrationController@postRegister');

Route::get('login/{provider}', 'Auth\RegistrationController@redirectToProvider');
Route::get('login/{provider}/callback', 'Auth\RegistrationController@handleProviderCallback');

Route::get('/login', 'Auth\LoginController@login');
Route::post('/login', 'Auth\LoginController@postLogin');

Route::post('/logout', 'Auth\LoginController@logout');

Route::get('/search/executeSearch/{keyword}', 'SearchController@executeSearch');
Route::post('/search/executeSearch/{keyword}', 'SearchController@executeSearch');



Route::get('/activate/{email}/{activationCode}', 'Auth\ActivationController@activate');
Route::get('/password/reset', 'Auth\ResetPasswordController@forgotPassword');
Route::post('/password/email', 'Auth\ResetPasswordController@postForgotPassword');
Route::get('/reset/{email}/{resetCode}', 'Auth\ResetPasswordController@resetPassword');
Route::post('/reset/{email}/{resetCode}', 'Auth\ResetPasswordController@postResetPassword');


Route::get('image-upload', 'ImageController@imageUpload');
Route::post('image-upload', 'ImageController@imageUploadPost');


//About Us Category
Route::group(['prefix' => 'about-us'], function () {
    Route::get('who-we-are', 'Index\AboutUs\WhoWeAreController@display');
    Route::get('rccg', 'Index\AboutUs\RccgController@display');
    Route::get('vision', 'Index\AboutUs\VisionController@display');
    Route::get('belief', 'Index\AboutUs\BeliefController@display');
    Route::get('pastor', 'PastorController@display');
    Route::get('services', 'Index\AboutUs\ServicesController@display');
    Route::get('contact', 'FormsController@contactDisplay');
    Route::post('contact/submit', 'FormsController@contactStore');
});
//End About Us

//Resources Category
Route::group(['prefix' => 'resources'], function () {
    Route::get('special_prayers', 'Index\SpecialPrayersController@display');
    Route::get('special_prayers/{filename}', 'Index\SpecialPrayersController@detail');
    Route::get('bulletins', function () {
        return view('index.resource_media.bulletins.index');
    });
    Route::get('bulletins/2013', function () {
        return view('index.resource_media.bulletins.2013');
    });
    Route::get('bulletins/2013/january', function () {
        return view('index.resource_media.bulletins.january_2013');
    });
    Route::get('bulletins/2013/february', function () {
        return view('index.resource_media.bulletins.february_2013');
    });
    Route::get('bulletins/2013/march', function () {
        return view('index.resource_media.bulletins.march_2013');
    });
    Route::get('bulletins/2014', function () {
        return view('index.resource_media.bulletins.2014');
    });
    Route::get('bulletins/2015', function () {
        return view('index.resource_media.bulletins.2015');
    });
    Route::get('bulletins/2016', function () {
        return view('index.resource_media.bulletins.2016');
    });
    Route::get('flyers', function () {
        return view('index.resource_media.flyers');
    });
    Route::get('special_prayers', 'Index\SpecialPrayersController@display');
    Route::get('special_prayers/{filename}', 'Index\SpecialPrayersController@detail');
    Route::get('upcoming-events', 'Index\UpcomingController@display');
    Route::resource('testimony', 'TestimoniesController');
    Route::get('testimony/{anything?}', 'TestimoniesController@anything');
    Route::resource('tracts', 'TractsController');
});


//Interactive Category
Route::group(['prefix' => 'interactive'], function () {
    Route::get('blogs', 'BlogsController@guestDisplay');
    Route::get('blogs/blog/{title}', 'BlogsController@guestDetail');
    Route::post('blogs/blog/{title}', 'BlogsController@guestDetail');

    Route::get('tracts', 'TractsController@index');
    Route::get('tracts/tract/{title}', 'TractsController@Detail');
    Route::post('tracts/tract/{title}', 'TractsController@Detail');

    Route::get('faq', function () {
        return view('index.interactive.faq');
    });
//    Route::get('ask-the-pastor', 'FormsController@pastorDisplay');
//    Route::post('ask-the-pastor/submit', 'FormsController@pastorStore');
//    Route::get('feedback', 'FormsController@feedbackDisplay');
//    Route::post('feedback/submit', 'FormsController@feedbackStore');
    Route::get('prayer-request', 'FormsController@prayerDisplay');
    Route::post('prayer-request/submit', 'FormsController@prayerStore');
    Route::get('testimony', 'TestimoniesController@create');
    Route::post('testimony/submit', 'TestimoniesController@store');
});

//Media Center Category

Route::group(['prefix' => 'media_center'], function () {
    Route::get('videos', function () {
        return view('index.media_center.videos');
    });
    Route::get('gallery', function () {
        return view('index.media_center.gallery');
    });

});

//End Media Center


//Route::get('/calendar','CalendarEventController@index');


//Route::get('/', 'HomeController@index');

Route::get('image-upload', 'ImageController@imageUpload');
Route::post('image-upload', 'ImageController@imageUploadPost');
Route::get('/dashboard', 'DashboardController@index');


Route::get('/admin/login', 'Auth\AdminController@showLoginForm');
Route::post('/admin/login', 'Auth\AdminController@postLogin');
/* BECKEND */
Route::group(['prefix' => 'admin', 'middleware' => 'admin'], function () {
    Route::get('/', 'Auth\AdminController@index');
    Route::post('/logout', 'Auth\AdminController@logout');
    Route::get('/testimonies', 'TestimoniesController@adminIndex');
    Route::get('/testimony/create', 'TestimoniesController@adminCreate');
    Route::post('/testimony/submit', 'TestimoniesController@adminStore');
    Route::put('/testimony/{testimony}', 'TestimoniesController@adminUpdate');
    Route::get('/testimony/{testimony}', 'TestimoniesController@adminShow');
    Route::get('/testimony/{testimony}/edit', 'TestimoniesController@adminEdit');
    Route::get('/testimony/{testimony}/delete', 'TestimoniesController@Destroy');
    Route::get('/testimonies/search/{keywords}', 'TestimoniesController@search');
    Route::get('/pastor/settings/', 'PastorController@edit');
    Route::put('/pastor/settings/', 'PastorController@update');
    Route::get('/general/settings/', 'SettingsController@edit');
    Route::put('/general/settings/', 'SettingsController@update');
    Route::put('/form/{id}/', 'FormsController@formSubmit');
    Route::get('/contact-form', 'FormsController@contactIndex');
    Route::get('/contact-form/{contact}', 'FormsController@contactShow');
    Route::get('/contact-form/{contact}/edit', 'FormsController@contactEdit');
    Route::get('/forms/{contact}/search/{keyword}', 'FormsController@search');
    Route::get('/prayer-form', 'FormsController@prayerIndex');
    Route::get('/prayer-form/{prayer}', 'FormsController@prayerShow');
    Route::get('/prayer-form/{pastor}/edit', 'FormsController@pastorEdit');
    Route::resource('faq', 'FAQController');
    Route::resource('blogs', 'BlogsController');
    Route::get('/blogs/search/{keywords}', 'BlogsController@search');
    Route::get('/tracts', 'TractsController@adminIndex');
    Route::get('/tract/create', 'TractsController@adminCreate');
    Route::get('/tract/search/{keywords}', 'BlogsController@search');
    Route::post('/tract/submit', 'TractsController@adminStore');
    Route::put('/tract/{tract}', 'TractsController@adminUpdate');
    Route::get('/tract/{tract}', 'TractsController@adminShow');
    Route::get('/tract/{tract}/edit', 'TractsController@adminEdit');
    Route::get('/tract/{tract}/delete', 'TractsController@Destroy');
    Route::resource('calendar_events', 'CalendarEventController');
    Route::resource('workers', 'WorkersController');
    Route::get('/users/search/{keywords}', 'UsersController@search');
    Route::resource('users', 'UsersController');
    Route::get('/workers/search/{keywords}', 'WorkersController@search');
    Route::get('/workers/{id}/permissions', 'WorkersController@displayPermissions');
    Route::post('/workers/{id}/permissions', 'WorkersController@postPermissions');
    Route::get('/slideshows', 'SlideshowController@index');
    Route::put('/slideshow/{slideshow}', 'SlideshowController@adminUpdate');
    Route::get('/slideshow/{slideshow}/edit', 'SlideshowController@adminEdit');
    Route::get('/slideshow/{slideshow}/delete', 'SlideshowController@Destroy');
    Route::get('/slideshow/create', 'SlideshowController@adminCreate');
    Route::post('/slideshow/submit', 'SlideshowController@adminStore');
});

