<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pastor extends Model
{
    protected $guarded = [];

    protected $table = 'pastor_settings';
}
