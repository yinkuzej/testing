<?php

namespace App\Http\Controllers\Auth;

use App\User;
use Cartalyst\Sentinel\Laravel\Facades\Activation;
use App\Http\Controllers\Controller;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;

class ActivationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function activate($email, $activationCode)
    {
        $user = User::whereEmail($email)->first();


        if (Activation::complete($user, $activationCode)) {

            return redirect('/login');

        } else {

        }
    }
}
