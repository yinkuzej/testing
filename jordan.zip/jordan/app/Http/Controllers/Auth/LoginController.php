<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Sentinel;
use Cartalyst\Sentinel\Checkpoints\ThrottlingException;
use Cartalyst\Sentinel\Checkpoints\NotActivatedException;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    public function login()
    {
        return view('auth.login');

    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function postLogin(Request $request)
    {

        try {

            $rememberMe = false;

            if (isset($request->remember)) {
                $rememberMe = true;
            }


            if (Sentinel::authenticate($request->all(),$rememberMe)) {

                return redirect('/');
            } else {
                return redirect('/login')->with('error', "Wrong Credentials");
            }

        } catch (ThrottlingException $e) {
            $delay = $e->getDelay();
            return redirect('/login')->with('error', "You are banned for $delay seconds after several login failure attempts");
        } catch (NotActivatedException $e) {
            return redirect('/login')->with('error', "Your account is not activated yet");
        }

    }

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function logout()
    {
        Sentinel::logout();
        return redirect('/login');
    }
}
