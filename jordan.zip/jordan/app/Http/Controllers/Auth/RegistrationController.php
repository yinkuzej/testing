<?php


namespace App\Http\Controllers\Auth;

use App\SocialProvider;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Laravel\Socialite\Facades\Socialite;
use League\Flysystem\Exception;
use Sentinel;
use Activation;
use App\User;
use Illuminate\Support\Facades\Mail;


class RegistrationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function register()
    {
        return view('auth.register');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function postRegister(Request $request)
    {

        $user = Sentinel::register($request->all());
        $activation = Activation::create($user);
//        $role = Sentinel::findRoleBySlug('admin');
//        $role->users()->attach($user);
        $this->sendEmail($user, $activation->code);
        return redirect('/');
    }

    private function sendEmail($user, $code)
    {

        Mail::send('emails.activation', [
            'user' => $user,
            'code' => $code
        ], function ($message) use ($user) {
            $message->to($user->email);
            $message->subject("Hello $user->first_name, activate your account.");
        });
    }


    /**
     * Redirect the user to the GitHub authentication page.
     *
     * @return Response
     */
    public function redirectToProvider($provider)
    {
        return Socialite::driver($provider)->redirect();
    }

    /**
     * Obtain the user information from GitHub.
     *
     * @return Response
     */
    public function handleProviderCallback($provider)
    {

        try {
            $socialUser = Socialite::driver($provider)->user();
        } catch (Exception $e) {

            return redirect('/');
        }

        $socialProvider = SocialProvider::where('provider_id', $socialUser->getId())->first();
        if(!$socialProvider){

            $full_name = explode(" ",$socialUser->getName());
            if (count($full_name) == 2){
                $first_name = $full_name[0];
                $last_name = $full_name[1];
            }elseif (count($full_name) > 2){
                $first_name = $full_name[0]." ".$full_name[1];
                $last_name = $full_name[2];
            }
            $user = Sentinel::registerAndActivate(
                [
                    'email' => $socialUser->getEmail(),
                    'first_name' => $first_name,
                    'last_name' => $last_name,
                    'password' => strtolower($first_name{0}).strtolower($last_name),
                    'reg_from_social_media' => 'Y',
                ]);

                $user->socialProviders()->create(
                    [
                        'provider_id' => $socialUser->getId(),
                        'provider' => $provider,
                    ]);
            Sentinel::login($user);
            return redirect('/dashboard');
        } else {
            $user = $socialProvider->user;
            Sentinel::login($user);
            return redirect('/dashboard');
        }

    }
}
