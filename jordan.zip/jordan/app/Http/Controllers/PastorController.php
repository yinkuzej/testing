<?php

namespace App\Http\Controllers;

use App\Pastor;
use Illuminate\Http\Request;

class PastorController extends Controller
{

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit()
    {
        $settings = Pastor::find(1);
        return view('admin.pastor_settings')->with('settings', $settings);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $input = $request->all();
        $settings = Pastor::find(1);
        $settings->fill($input);
        $settings->save();
        return redirect(asset('admin/pastor/settings'));
    }

    /**
     * @return view
     */
    public function display()
    {
        $settings = Pastor::find(1);
        return view('index.about_us.pastor')->with('settings', $settings);
    }



}
