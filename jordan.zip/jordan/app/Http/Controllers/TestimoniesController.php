<?php

namespace App\Http\Controllers;

use App\Testimony;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TestimoniesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $testimonies = Testimony::where('display', 'Y')->orderBy('created_at')->paginate(3);

        return view('index.testimonies')->withTestimonies($testimonies);
    }

    public function adminIndex()
    {
        $testimonies = DB::table('testimonies')->latest()->paginate(3);

        return view('admin.testimonies_all')->withTestimonies($testimonies);
    }

    public function search($keywords)
    {
        $testimonies = Testimony::where('name', 'like', '%' . $keywords . '%')->orderBy('created_at')->paginate(5);

        return view('admin.testimonies_all')->withTestimonies($testimonies)->with('keywords',$keywords);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function Detail(Request $request,$id)
    {
//        if (isset($_GET['comment'])){
//            BlogComment::create($request->all());
////            Redirect::to(->previousUrl() . "#comment");
//            return back();
//        }


        $tract = Blog::where('link', $id)->first();

        if (!$tract) {
            return redirect('/interactive/tracts')->withErrors('Requested Tract not found');
        }else{

            $tract->views = $tract->increment('views');
        }


//        $category = $tract->category;

//        $comments = BlogComment::where('blog_id', $blog->id)->orderBy('created_at')->paginate(5);
        return view('index.interactive.tract.detail')->withblog($blog)->withCategory($category)->withComments($comments);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('index.interactive.testimony_add');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function adminCreate()
    {
        return view('admin.testimony_add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $testimony_id = Testimony::create($request->all())->id;

        if ($testimony_id) {

            return redirect(asset('interactive/testimony'))->withSuccess('The testimony has been submitted successfully!');
        } else {
            return redirect(asset('interactive/testimony'))->withError('The testimony has not been submitted successfully!');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function adminStore(Request $request)
    {
        if ($request->display === 'on') {
            $request->merge( array( 'display' => 'Y' ) );
        } else {
            $request->merge( array( 'display' => 'N' ) );
        }

        $testimony_id = Testimony::create($request->all())->id;

        if ($testimony_id) {

            return redirect(asset('/admin/testimony/' . $testimony_id . '/edit'))->withSuccess('The testimony has been submitted successfully!');
        } else {
            return redirect(asset('/admin/testimonies'))->withError('The testimony has not been submitted successfully!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function adminShow($id)
    {
        $testimony = Testimony::find($id);
        return view('admin.testimony_detail')->with('testimony', $testimony);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $testimony = Testimony::find($id);
        return view('index.testimony_edit')->withTestimonies($testimony);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function adminEdit($id)
    {
        $testimony = Testimony::find($id);
        return view('admin.testimony_edit')->with('testimony', $testimony);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $input = $request->all();
        $testimony = Testimony::find($id);
        $testimony->fill($input);
        $testimony->save();
        return redirect(asset('interactive/testimony'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function adminUpdate(Request $request, $id)
    {
        if ($request->display === 'on') {
            $request->merge( array( 'display' => 'Y' ) );
        } else {
            $request->merge( array( 'display' => 'N' ) );
        }

        $input = $request->all();

        $testimony = Testimony::find($id);
        $testimony->fill($input);
        $testimony->save();
        return redirect(asset('/admin/testimony/'.$id));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (Testimony::destroy($id)) {

            return redirect(asset('admin/testimonies'))->withSuccess('The testimony has been deleted successfully!');;
        } else {
            return redirect(asset('/admin/testimony/' . $id . '/edit'))->withErrors('The testimony could not be deleted!');
        }
    }

}
