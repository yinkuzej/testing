<?php

namespace App\Http\Controllers;

use App\Slideshow;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class SlideshowController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $slideshows = DB::table('slideshows')->orderBy('order')->paginate(10);

        return view('admin.slideshows.all')->withSlideshows($slideshows);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function adminCreate()
    {
        return view('admin.slideshows.add');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function adminStore(Request $request)
    {
        if ($request->display === 'on') {
            $request->merge( array( 'display' => 'yes' ) );
        } else {
            $request->merge( array( 'display' => 'no' ) );
        }


        $image = $request->file('file');
        $imageFileName = time() . '.' . $image->getClientOriginalExtension();
        $s3 = Storage::disk('s3');
        $s3->put($imageFileName, file_get_contents($image), 'public');
        $imageName = $s3->url($imageFileName);

        if(!empty($imageName)) {
            $slideshow_id = Slideshow::create($request->except('file') + [ 'image' => $imageName])->id;
        }
        if ($slideshow_id) {

            return redirect(asset('/admin/slideshow/' . $slideshow_id . '/edit'))->withSuccess('The slideshow has been submitted successfully!');
        } else {
            return redirect(asset('/admin/slideshows'))->withError('The slideshow has not been submitted successfully!');
        }
    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function adminEdit($id)
    {
        $slideshow = Slideshow::find($id);
        return view('admin.slideshows.edit')->with('slideshow', $slideshow);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function adminUpdate(Request $request, $id)
    {
        if ($request->display === 'on') {
            $request->merge( array( 'display' => 'Y' ) );
        } else {
            $request->merge( array( 'display' => 'N' ) );
        }

        $input = $request->all();

        $slideshow = Slideshow::find($id);
        $slideshow->fill($input);
        $slideshow->save();
        return redirect(asset('/admin/slideshow/'.$id.'/edit'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (Slideshow::destroy($id)) {

            return redirect(asset('admin/slideshows'))->withSuccess('The Slideshow has been deleted successfully!');;
        } else {
            return redirect(asset('/admin/slideshow/' . $id . '/edit'))->withErrors('The Slideshow could not be deleted!');
        }
    }

}
