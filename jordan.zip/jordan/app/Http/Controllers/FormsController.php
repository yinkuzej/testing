<?php

namespace App\Http\Controllers;

use App\Forms;
use Illuminate\Http\Request;

class FormsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function contactIndex()
    {
        $contact_forms = Forms::where('form_type', 'contact')->orderBy('created_at')->paginate(3);

        return view('admin.contact_all')->with('contact_forms', $contact_forms);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function contactDisplay()
    {
        return view('index.about_us.contact_us');
    }

    public function search($type,$keywords)
    {


        $form = Forms::where([
            ['form_type', '=',  $type ],
            ['first_name', 'like', '%' . $keywords . '%'],

        ])->orWhere([
            ['form_type', '=',  $type ],
            ['last_name', 'like', '%' . $keywords . '%'],

        ])->paginate(5);
        if($type =='contact'){

            return view('admin.contact_all')->with('contact_forms',$form)->with('keywords',$keywords);
        } else  if($type =='prayer'){
            return view('admin.prayer_all')->with('contact_forms',$form)->with('keywords',$keywords);

        }
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function contactStore(Request $request)
    {
        $form_id = Forms::create($request->all())->id;

        if ($form_id) {

            return redirect(asset('/about-us/contact'))->withSuccess('The Contact Form has been submitted successfully!');
        } else {
            return redirect(asset('/about-us/contact'))->withError('The Contact Form has not been submitted successfully!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function contactShow($id)
    {
        $form = Forms::find($id);
        return view('admin.form_detail')->with('form', $form);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function contactEdit($id)
    {
        $form = Forms::find($id);
        return view('admin.form_edit')->with('form', $form);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function pastorDisplay()
    {
        return view('index.interactive.ask_the_pastor');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function pastorStore(Request $request)
    {
        $form_id = Forms::create($request->all())->id;

        if ($form_id) {

            return redirect(asset('/interactive/ask-the-pastor'))->withSuccess('Your Question has been submitted successfully!');
        } else {
            return redirect(asset('/interactive/ask-the-pastor'))->withError('Your Question has not been submitted successfully!');
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function pastorIndex()
    {
        $contact_forms = Forms::where('form_type', 'pastor')->orderBy('created_at')->paginate(3);

        return view('admin.pastor_all')->with('contact_forms', $contact_forms);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function pastorShow($id)
    {
        $form = Forms::find($id);
        return view('admin.form_detail')->with('form', $form);
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function feedbackDisplay()
    {
        return view('index.interactive.feedback');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function pastorEdit($id)
    {
        $form = Forms::find($id);
        return view('admin.form_edit')->with('form', $form);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function feedbackStore(Request $request)
    {
        $form_id = Forms::create($request->all())->id;

        if ($form_id) {

            return redirect(asset('/interactive/feedback'))->withSuccess('Your Feedback has been submitted successfully!');
        } else {
            return redirect(asset('/interactive/feedback'))->withError('Your Feedback has not been submitted successfully!');
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function feedbackIndex()
    {
        $contact_forms = Forms::where('form_type', 'feedback')->orderBy('created_at')->paginate(3);

        return view('admin.feedback_all')->with('contact_forms', $contact_forms);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function feedbackShow($id)
    {
        $form = Forms::find($id);
        return view('admin.form_detail')->with('form', $form);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function prayerDisplay()
    {
        return view('index.interactive.prayer_request');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function prayerStore(Request $request)
    {
        $form_id = Forms::create($request->all())->id;

        if ($form_id) {

            return redirect(asset('/interactive/prayer-request'))->withSuccess('Your Feedback has been submitted successfully!');
        } else {
            return redirect(asset('/interactive/prayer-request'))->withError('Your Feedback has not been submitted successfully!');
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function prayerIndex()
    {
        $contact_forms = Forms::where('form_type', 'prayer')->orderBy('created_at')->paginate(3);

        return view('admin.prayer_all')->with('contact_forms', $contact_forms);
    }



    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function formSubmit(Request $request, $id)
    {
        if ($request->form_type == 'prayer') {
            if ($request->allow_contact === 'on') {
                $request->merge(array('allow_contact' => 'yes'));
            } else {
                $request->merge(array('allow_contact' => 'no'));
            }
        }

        $input = $request->all();

        $type = $request->form_type;
        $form = Forms::find($id);
        $form->fill($input);
        $form->save();
        if ($type == 'contact') {
            return redirect(asset('admin/contact-form/' . $id));
        } elseif ($type == 'pastor') {
            return redirect(asset('admin/pastor-form/' . $id));
        } elseif ($type == 'feedback') {
            return redirect(asset('admin/feedback-form/' . $id));
        } elseif ($type == 'prayer') {
            return redirect(asset('admin/prayer-form/' . $id));
        }

    }


    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function feedbackEdit($id)
    {
        $form = Forms::find($id);
        return view('admin.form_edit')->with('form', $form);
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function prayerShow($id)
    {
        $form = Forms::find($id);
        return view('admin.form_detail')->with('form', $form);
    }

}
