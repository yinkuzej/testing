<?php

namespace App\Http\Controllers;

use App\Tracts;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Input;
use Validator;
use Response;

class TractsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tracts = Tracts::where('display', 'yes')->orderBy('created_at')->paginate(3);

        return view('index.interactive.tracts.index')->withTracts($tracts);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function Detail(Request $request,$id)
    {
//        if (isset($_GET['comment'])){
//            BlogComment::create($request->all());
////            Redirect::to(->previousUrl() . "#comment");
//            return back();
//        }


        $tract = Tracts::where('url', $id)->first();

        if (!$tract) {
            return redirect('/interactive/tracts')->withErrors('Requested Tract not found');
        }else{

            $tract->views = $tract->increment('views');
        }


//        $category = $blog->category;

//        $comments = BlogComment::where('blog_id', $blog->id)->orderBy('created_at')->paginate(5);
        return view('index.interactive.tracts.detail')->withTract($tract)/*->withCategory($category)->withComments($comments)*/;
    }

    /**
     * @return mixed
     */
    public function adminIndex()
    {
        $tracts = DB::table('tracts')->latest()->paginate(3);

        return view('admin.tracts_all')->withTracts($tracts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function adminCreate()
    {
        return view('admin.tract_add');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function adminEdit($id)
    {
        $tract = Tracts::find($id);
        return view('admin.tract_edit')->with('tract', $tract);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function adminUpdate(Request $request, $id)
    {
        if ($request->display === 'on') {
            $request->merge(array('display' => 'yes'));
        } else {
            $request->merge(array('display' => 'no'));
        }

        $input = $request->all();

        $tract = Tracts::find($id);
        $tract->fill($input);
        $tract->save();
        return redirect(asset('/admin/tract/' . $id));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function adminShow($id)
    {
        $tract = Tracts::find($id);
        return view('admin.tract_edit')->with('tract', $tract);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
//        $input = Input::all();
//        dd($input);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function adminStore(Request $request)
    {

        if ($request->display === 'on') {
            $request->merge(array('display' => 'yes'));
        } else {
            $request->merge(array('display' => 'no'));
        }

        $tract_id = Tracts::create($request->all())->id;

        if ($tract_id) {

            return redirect(asset('/admin/tracts'))->withSuccess('The Tract has been submitted successfully!');
        } else {
            return redirect(asset('/admin/tracts'))->withError('The Tract has not been submitted successfully!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
