<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use  Oblagio\Instagram\InstagramFacade as IG;

class HomeController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $instagram_images = IG::standardResolution(5);
        return view('index.index')->with('instagram_images',$instagram_images);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function submitContactForm(Request $request)
    {
        return redirect('/#contact')->with('message', 'Thank you For your submission.');
    }
}
