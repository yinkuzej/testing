<?php

namespace App\Http\Controllers;

use App\FAQ;
use Illuminate\Http\Request;

class FAQController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $faqs = FAQ::paginate(3);
        return view('admin.faqs_all')->withFaqs($faqs);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.faq_add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        if ($request->display === 'on') {
            $request->merge( array( 'display' => 'yes' ) );
        } else {
            $request->merge( array( 'display' => 'no' ) );
        }
        $faq_id = FAQ::create($request->all())->id;

        if ($faq_id) {

            return redirect(asset('admin/faq'))->withSuccess('The faq has been submitted successfully!');
        } else {
            return redirect(asset('admin/faq'))->withError('The faq has not been submitted successfully!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $faq = FAQ::find($id);
        return view('admin.faq_detail')->with('faq', $faq);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $faq = FAQ::find($id);

        return view('admin.faq_edit')->withfaq($faq);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ($request->display === 'on') {
            $request->merge( array( 'display' => 'yes' ) );
        } else {
            $request->merge( array( 'display' => 'no' ) );
        }

        $input = $request->all();
        $faq = FAQ::find($id);
        $faq->fill($input);
        $faq->save();
        return redirect(asset('admin/faq'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $calendar_event = FAQ::findOrFail($id);
        $calendar_event->delete();
        return redirect(asset('/admin/calendar_events'))->with('message', 'Item deleted successfully.');
    }
}
