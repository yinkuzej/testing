<?php

namespace App\Http\Controllers;

use App\CalendarEvent;
use App\Http\Requests;
use Illuminate\Http\Request;

class CalendarEventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $calendar_events = CalendarEvent::all();
        return view('admin.calendar_events.index', compact('calendar_events'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('admin.calendar_events.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
//        dd($request);
        $allday = ($request->input("allDay") == 'true') ? true : false;
        $start= strtotime($request->input("start"));
        $end = ($request->input("end") == '') ? $start : strtotime($request->input("end"));
        $calendar_event = new CalendarEvent();
        $calendar_event->title = $request->input("title");
        $calendar_event->start = $start;
        $calendar_event->end = $end;
        $calendar_event->allDay = $allday;
        $calendar_event->background_color = $request->input("background_color");
        $calendar_event->save();
        return redirect(asset('/admin/calendar_events'))->with('message', 'Item created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function show($id)
    {
        $calendar_event = CalendarEvent::findOrFail($id);
        return view('admin.calendar_events.show', compact('calendar_event'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return Response
     */
    public function edit($id)
    {
        $calendar_event = CalendarEvent::findOrFail($id);
        return view('admin.calendar_events.edit', compact('calendar_event'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int $id
     * @param Request $request
     * @return Response
     */
    public function update(Request $request, $id)
    {
        $calendar_event = CalendarEvent::findOrFail($id);

        $allday = ($request->input("allDay") == 'true') ? true : false;
        $start= strtotime($request->input("start"));
        $end = ($request->input("end") == '') ? $start : strtotime($request->input("end"));
        $calendar_event->title = $request->input("title");
        $calendar_event->start = $start;
        $calendar_event->end = $end;
        $calendar_event->allDay = $allday;
        $calendar_event->background_color = $request->input("background_color");
        $calendar_event->save();
        return redirect(asset('/admin/calendar_events'))->with('message', 'Item updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return Response
     */
    public function destroy($id)
    {
        $calendar_event = CalendarEvent::findOrFail($id);
        $calendar_event->delete();
        return redirect(asset('/admin/calendar_events'))->with('message', 'Item deleted successfully.');
    }

}
