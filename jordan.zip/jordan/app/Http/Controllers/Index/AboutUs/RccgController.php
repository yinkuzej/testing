<?php
/**
 * Created by PhpStorm.
 * User: adeol
 * Date: 11/29/2016
 * Time: 12:03 AM
 */

namespace App\Http\Controllers\Index\AboutUs;
use App\Http\Controllers\Controller;

class RccgController extends Controller
{
    /**
     * @return view
     */
    public function display()
    {

        return view('index.about_us.rccg');
    }


}