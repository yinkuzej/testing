<?php
/**
 * Created by PhpStorm.
 * User: adeol
 * Date: 11/29/2016
 * Time: 1:39 AM
 */

namespace App\Http\Controllers\Index\AboutUs;
use App\Http\Controllers\Controller;

class BeliefController extends Controller
{
    /**
     * @return view
     */
    public function display()
    {

        return view('index.about_us.belief');
    }


}