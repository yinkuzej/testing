<?php

namespace App\Http\Controllers\Index\AboutUs;

use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;


class WhoWeAreController extends Controller {

    /**
     * @return view
     */
    public function display()
    {

        return view('index.about_us.who_we_are');
    }


}
