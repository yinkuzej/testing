<?php
/**
 * Created by PhpStorm.
 * User: adeol
 * Date: 12/14/2016
 * Time: 9:39 PM
 */

namespace App\Http\Controllers\Index;

use App\CalendarEvent;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

class UpcomingController  extends Controller {




    /**
     * @var CalendarEvent
     */
    private $calendarEvent;


    /**
     * @param CalendarEvent $calendarEvent
     */
    public function __construct(CalendarEvent $calendarEvent)
    {
        $this->calendarEvent = $calendarEvent;
    }

    /**
     * @return view
     */
    public function display()
    {
        $staticEvent = \Calendar::event(
            'Today\'s Sample',
            true,
            Carbon::today()->setTime(0, 0),
            Carbon::today()->setTime(23, 59),
            null,
            [
                'color' => '#0F0',
                'url' => 'http://google.com',
            ]
        );
        $databaseEvents = $this->calendarEvent->all();
        $calendar = \Calendar::addEvent($staticEvent)->addEvents($databaseEvents);
        return view('index.resource_media.upcoming', compact('calendar'));
    }

}