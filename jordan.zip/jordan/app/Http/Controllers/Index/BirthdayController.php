<?php
/**
 * Created by PhpStorm.
 * User: adeol
 * Date: 12/14/2016
 * Time: 9:47 PM
 */

namespace App\Http\Controllers\Index;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Vics80\Calendar\Facades\Calendar;
use Illuminate\Support\Facades\DB;

class BirthdayController extends Controller {

    /**
     * @return view
     */
//    public function display()
//    {
//
//        $json = array();
//        $events = DB::select(DB::raw("SELECT * FROM events ORDER BY id;"));
//
//
//
//        foreach ($events as $event) {
//            $subArr = [
//                'id' => $event->id,
//                'title' => $event->title,
//                'start' => $event->start,
//                'end' => $event->end,
//            ];
//            array_push($json, $subArr);
//
//        }
//
//
//
//        return view('index.resource_media.birthdays')->with('json', $json);
//    }


}