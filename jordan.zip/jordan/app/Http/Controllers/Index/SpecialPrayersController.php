<?php
/**
 * Created by PhpStorm.
 * User: adeol
 * Date: 12/28/2016
 * Time: 11:15 AM
 */

namespace App\Http\Controllers\Index;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\RedirectResponse;


class SpecialPrayersController extends Controller {

    /**
     * @return view
     */
    public function display()
    {
        $prayers= DB::select(DB::raw("SELECT * FROM special_prayers;"));
        return view('index.resource_media.special_prayers.index')->with('prayers',$prayers);
    }

    /**
     * @return view
     */
    public function detail($filename)
    {

        $prayer= collect(DB::select("SELECT * FROM special_prayers WHERE filename = '".$filename."';"))->first();

        if (!empty($prayer)) {
            return view('index.resource_media.special_prayers.details')->with('prayer', $prayer);
        }else{
            return redirect('/resources/special_prayers');
        }
    }


}