<?php

namespace App\Http\Controllers;

use App\BlogComment;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Blog;
use Illuminate\Session\Store;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class BlogsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $blogs = Blog::where('active', '1')->orderBy('created_at')->paginate(5);

        return view('admin.blogs')->withBlogs($blogs);
    }

    public function search($keywords)
    {
        $blogs = Blog::where('title', 'like', '%' . $keywords . '%')->orderBy('created_at')->paginate(5);

        return view('admin.blogs')->withBlogs($blogs)->with('keywords',$keywords);
    }

     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function guestDisplay()
    {
        $blogs = Blog::where('active', '1')->orderBy('created_at')->paginate(5);

        return view('index.interactive.blogs.index')->withBlogs($blogs);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $menus = DB::table('menu')->get();
        return view('admin.blog_add')->withMenus($menus);;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $blog_id = Blog::create($request->all())->id;
        return redirect(asset('/admin/blogs/' . $blog_id))->withMessage('The blog has been created successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $blog = Blog::where('id', $id)->first();

        if (!$blog) {
            return redirect('/')->withErrors('Requested blog not found');
        }
        $category = $blog->category;



        return view('admin.blog_show')->withblog($blog)->withCategory($category);
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function guestDetail(Request $request,$id)
    {
        if (isset($_GET['comment'])){
            BlogComment::create($request->all());
//            Redirect::to(->previousUrl() . "#comment");
            return back();
        }


        $blog = Blog::where('link', $id)->first();

        if (!$blog) {
            return redirect('/interactive/blogs')->withErrors('Requested blog not found');
        }else{

            $blog->views = $blog->increment('views');
        }


        $category = $blog->category;

        $comments = BlogComment::where('blog_id', $blog->id)->orderBy('created_at')->paginate(5);
        return view('index.interactive.blogs.detail')->withblog($blog)->withCategory($category)->withComments($comments);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $blog = Blog::where('id', $id)->first();
        $menus = DB::table('menu')->get();
        return view('admin.blog_edit')->withblog($blog)->withMenus($menus);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $input = $request->all();
        $blog = Blog::find($id);
        $blog->fill($input);
        $blog->save();

        return redirect(asset('/admin/blogs/' . $id))->withMessage('The blog has been updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Blog::destroy($id);
        return redirect(asset('admin/blogs/'))->withMessage('The blog has been deleted successfully!');
    }

    /**
     * @return string
     */
//    public function display($category_link, $blog_link)
//    {
//        $blog = Blogs::where('link', $blog_link)->first();
//        dd($blog);
//        return view('index.display')->withblog($blog);
//    }
}
