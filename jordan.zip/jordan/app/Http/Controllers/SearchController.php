<?php

namespace App\Http\Controllers;

use App\Blog;
use App\Forms;
use App\Testimony;
use App\Tracts;
use App\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Str;

class SearchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function executeSearch(Request $request, $phrase)
    {
        $keywords = $request->get('keywords');
        if ($phrase == 'blogs') {
            $blogs = Blog::where('title', 'like', '%' . $keywords . '%')->paginate(5);
            $blogs->setpath('/admin/blogs');

            return [
                'posts' => View('searchedBlogs')->with('searchBlogs', $blogs)->with('phrase', $phrase)->render(),
                'pagination' => View('pagination')->with('searchBlogs', $blogs)->with('phrase', $phrase)->with('keywords', $keywords)->render()
            ];

        } else if ($phrase == 'testimonies') {

            $testimonies = Testimony::where('name', 'like', '%' . $keywords . '%')->paginate(5);
            $testimonies->setpath('/admin/testimonies');

            return [
                'posts' => View('searchedBlogs')->with('searchBlogs', $testimonies)->with('phrase', $phrase)->render(),
                'pagination' => View('pagination')->with('searchBlogs', $testimonies)->with('keywords', $keywords)->with('phrase', $phrase)->render()
            ];
        } else if ($phrase == 'contact' || $phrase == 'prayer') {

            $forms =  Forms::where([
                ['form_type', '=',  $phrase ],
                ['first_name', 'like', '%' . $keywords . '%'],

            ])->orWhere([
                ['form_type', '=',  $phrase ],
                ['last_name', 'like', '%' . $keywords . '%'],

            ])->paginate(5);

            return [
                'posts' => View('searchedBlogs')->with('searchBlogs', $forms)->with('phrase', $phrase)->render(),
                'pagination' => View('pagination')->with('searchBlogs', $forms)->with('keywords', $keywords)->with('phrase', $phrase)->render()
            ];
        } else if ($phrase == 'tracts') {

            $tracts = Tracts::where('name', 'like', '%' . $keywords . '%')->paginate(5);

            return [
                'posts' => View('searchedBlogs')->with('searchBlogs', $tracts)->with('phrase', $phrase)->render(),
                'pagination' => View('pagination')->with('searchBlogs', $tracts)->with('keywords', $keywords)->with('phrase', $phrase)->render()
            ];

        } else if ($phrase == 'workers') {

            $worker = User::where([
                ['isWorker', '=',  'yes' ],
                ['first_name', 'like', '%' . $keywords . '%'],
            ])->orWhere([
                ['isWorker', '=',  'yes' ],
                ['last_name', 'like', '%' . $keywords . '%'],
            ])->paginate(5);

            return [
                'posts' => View('searchedBlogs')->with('searchBlogs', $worker)->with('phrase', $phrase)->render(),
                'pagination' => View('pagination')->with('searchBlogs', $worker)->with('keywords', $keywords)->with('phrase', $phrase)->render()
            ];

        }  else if ($phrase == 'users') {

            $worker = User::where([
                ['isWorker', '=',  'no' ],
                ['first_name', 'like', '%' . $keywords . '%'],
            ])->orWhere([
                ['isWorker', '=',  'no' ],
                ['last_name', 'like', '%' . $keywords . '%'],
            ])->paginate(5);

            return [
                'posts' => View('searchedBlogs')->with('searchBlogs', $worker)->with('phrase', $phrase)->render(),
                'pagination' => View('pagination')->with('searchBlogs', $worker)->with('keywords', $keywords)->with('phrase', $phrase)->render()
            ];

        }

    }
}
