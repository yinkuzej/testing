<?php

namespace App\Http\Controllers;

use App\Settings;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit()
    {

        $settings = Settings::find(1);
        return view('admin.general_settings')->with('settings', $settings);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        if ($request->next_event_display === 'on') {
            $request->merge( array( 'next_event_display' => 'yes' ) );
        } else {
            $request->merge( array( 'next_event_display' => 'no' ) );
        }

        $input = $request->all();
        $settings = Settings::find(1);
        $settings->fill($input);
        $settings->save();
        return redirect(asset('admin/general/settings'));
    }

}
