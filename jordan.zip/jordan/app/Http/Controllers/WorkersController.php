<?php

namespace App\Http\Controllers;

use App\User;
use Cartalyst\Sentinel\Native\Facades\Sentinel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WorkersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $workers = User::where('isWorker', 'yes')->paginate(5);

        return view('admin.workers.index')->withWorkers($workers);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $worker = User::findorFail($id);
        if (!empty($worker)) {
            return view('admin.workers.detail')->with('worker', $worker);

        } else {
            return redirect('/admin/workers');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $worker = User::findorFail($id);
        if (!empty($worker)) {
            return view('admin.workers.edit')->with('worker', $worker);

        } else {
            return redirect('/admin/workers');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $calendar_event = User::findOrFail($id);
        $calendar_event->delete();
        return redirect(asset('/admin/calendar_events'))->with('message', 'Item deleted successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function search($keywords)
    {
        $workers = User::where([
            ['isWorker', '=', 'yes'],
            ['first_name', 'like', '%' . $keywords . '%'],
        ])->orWhere([
            ['isWorker', '=', 'yes'],
            ['last_name', 'like', '%' . $keywords . '%'],
        ])->paginate(5);

        return view('admin.workers.index')->with('workers', $workers);

    }


    /**
     * Remove the specified resource from storage.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     * @internal param int $id
     */
    public function postPermissions(Request $request, $id)
    {
        $user = Sentinel::findById(intval($id));

        unset($request['_token']);
        foreach ($request->all() as $key => $value) {
            $permissions[str_replace('_', '.', $key)] = $value;
        }
        $user->permissions = $permissions;
        $user->save();
        $a = $user->getPermissions();
        return view('admin.workers.permissions')->with('permissions', $a)->with('id', $id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function displayPermissions($id)
    {
        $user = Sentinel::findById(intval($id));

//        $user->permissions = [
//            // BLOG
//            'blog.create' => true,
//            'blog.delete' => true,
//            'blog.update' => true,
//            'blog.select' => true,
//
//            //USERS
//            'user.create' => true,
//            'user.delete' => false,
//            'user.update' => true,
//            'user.select' => true,
//
//            // FORMS
//            'contact_form.view' => true,
//            'contact_form.delete' => true,
//            'feedback_form.view' => true,
//            'feedback_form.delete' => true,
//            'pastor_form.view' => true,
//            'pastor_form.delete' => true,
//            'prayer_form.view' => true,
//            'prayer_form.delete' => true,
//
//            //Testimonies
//            'testimony.create' => true,
//            'testimony.delete' => false,
//            'testimony.update' => true,
//            'testimony.select' => true,
//
//            //Pastor's Settings
//            'pastor_settings.update' => true,
//
//            //FAQ
//            'faq.create' => true,
//            'faq.delete' => false,
//            'faq.update' => true,
//            'faq.select' => true,
//
//            //Calendar Events
//            'calendar.create' => true,
//            'calendar.delete' => false,
//            'calendar.update' => true,
//            'calendar.select' => true,
//
//            //Workers Settings
//            'worker.create' => true,
//            'worker.delete' => false,
//            'worker.update' => true,
//            'worker.select' => true,
//            'worker.permissions' => true,
//
//        ];
//        $user->save();
        $a = $user->getPermissions();
        return view('admin.workers.permissions')->with('permissions', $a)->with('id', $id);
    }
}
