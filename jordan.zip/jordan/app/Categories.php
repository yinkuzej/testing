<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categories extends Model
{
    protected $guarded = [];

    /**
     * @return array
     */
    public function blogs()
    {
        return $this->hasMany('App\Blog', 'category_id', 'id');
    }
}
