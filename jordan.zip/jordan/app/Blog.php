<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    protected $guarded = [];

    /**
     * @return array
     */
    public function category()
    {
        return $this->belongsTo('App\Categories');
    }

    /**
     * @return array
     */
    public function author()
    {
        return $this->belongsTo('App\User', 'user_id' ,'id');
    }

    /**
     * @return array
     */
    public function getAuthorName()
    {
        return $this->author->getFullName();
    }

    /**
     * @return array
     */
    public function comments()
    {
        return $this->hasMany('App\BlogComment', 'blog_id' ,'id');
    }

    # Use this to count the likes
    public function getCommentsCount(){
        return $this->comments->count();
    }

}
