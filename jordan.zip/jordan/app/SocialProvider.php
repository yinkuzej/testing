<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SocialProvider extends Model
{
    protected $guarded = [];

    protected $table = 'social_providers';


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'provider_id',
        'provider'
    ];

    function  user(){
        return $this->belongsTo(User::class);
    }


}
