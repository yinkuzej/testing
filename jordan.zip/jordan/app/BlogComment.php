<?php

namespace App;

use Carbon\Carbon;
use DateTimeZone;
use Illuminate\Database\Eloquent\Model;

class BlogComment extends Model
{
    protected $guarded = [];

    protected $table = 'blog_comments';
    protected $fillable = ['user_id','blog_id','comment','display'];


    /**
     * @return array
     */
    public function author()
    {
        return $this->belongsTo('App\User', 'user_id' ,'id');
    }

    /**
     * @return array
     */
    public function getAuthorName()
    {
        return $this->author->getFullName();
    }

    /**
     * @return array
     */
    public function getDays()
    {
        $created = new Carbon($this->created_at, 'America/Vancouver');
        $now = Carbon::now(new DateTimeZone('America/Vancouver'));


        if($created->diffInHours($now) < 24){
            $difference = 'yesterday';
        }else{
            $difference =  $created->diffForHumans($now);
        }

        return $difference.' at '.$this->created_at->Format('g:i A') ;
    }
}
