<?php

use App\Categories;
use App\Settings;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Illuminate\Support\Collection;
use Illuminate\Support\Debug\Dumper;
use Illuminate\Contracts\Support\Htmlable;
if (!function_exists('getMenu')) {
    /**
     * Return the given object. Useful for chaining.
     *
     * @param  mixed $object
     * @return mixed
     */
    function getMenu()
    {
        $menu = Categories::all();

        foreach ($menu as $c) {
            $c->push($c->pages);
        }

        return $menu;
    }
}

if (!function_exists('showEvent')) {
    /**
     * @return bool
     */
    function showEvent()
    {
        $settings  = Settings::find(1);

        if (strtolower($settings->next_event_display) == 'yes') {
            return true;
        } else  {
            return false;
        }
    }
}

if (!function_exists('getEventSettings')) {
    /**
     * @return bool
     */
    function getEventSettings()
    {
        $settings  = Settings::find(1);

       return $settings;
    }
}

if (!function_exists('truncate')) {
    /**
     * @return bool
     */
    function truncate($string,$link=null,$size=null)
    {

        if (is_null($size)){
            $size = 500;
        }

        // strip tags to avoid breaking any html
        $string = strip_tags($string);

        if (strlen($string) > $size) {

            // truncate string
            $stringCut = substr($string, 0, $size);

            // make sure it ends in a word so assassinate doesn't become ass...
            if (!is_null($link)){
                $text =  "... <a  class='ui button' href='$link'>Read More</a>";
            }else{
                $text='';
            }
            $string = substr($stringCut, 0, strrpos($stringCut, ' ')). $text ;
        }else {
            // make sure it ends in a word so assassinate doesn't become ass...
            if (!is_null($link)){
                $text =  "... <a  class='ui button' href='$link'>Read More</a>";
            }else{
                $text='';
            }
            $string = $string. $text ;
        }

       return $string;
    }
}