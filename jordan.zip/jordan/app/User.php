<?php

namespace App;

use Cartalyst\Sentinel\Native\Facades\Sentinel;
use Cartalyst\Sentinel\Users\EloquentUser;
use Illuminate\Notifications\Notifiable;

class User extends EloquentUser
{
    use Notifiable;

    protected $guarded = [];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'email',
        'password',
        'last_name',
        'first_name',
        'permissions',
        'location',
        'reg_from_social_media'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * Get all the user's all comments
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function comments()
    {
        return $this->hasMany('App\BlogComment', 'user_id', 'id');
    }

    /**
     * Get all the user's all posts
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function posts()
    {
        return $this->hasMany('App\Blog', 'user_id', 'id');
    }

    /**
     * Get all the user's all posts
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function tracts()
    {
        return $this->hasMany('App\Tracts', 'user_id', 'id');
    }

    /**
     * Check if the user is admin
     * @return bool
     */
    public function is_admin()
    {
        $role = $this->role;

        if ($role == 'admin') {
            return true;
        }

        return false;
    }

    public static function byEmail($email)
    {
        return static::whereEmail($email)->first();
    }


    public function permissions()
    {
        return $this->hasOne('App\Permission');
    }


    /**
     * @return array
     */
    public function getFullName()
    {
        return ucfirst($this->first_name) . ' ' . ucfirst($this->last_name);
    }

    function socialProviders()
    {
        return $this->hasMany(SocialProvider::class);

    }
}
